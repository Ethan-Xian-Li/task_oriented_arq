from util.utils import int_2_binary, timing_decorator, Q_function, sin_round
from torch.distributions import Exponential
import torch
import torch.nn.functional as F


class WirelessComm:
    def __init__(self, **kwargs):
        self.com_channel_mode = kwargs.get('wirelesscom_channel_mode')
        self.SNR_mean_in_dB = kwargs.get('SNR_mean_in_dB')
        self.batch_size = kwargs.get('batch_size')
        self.quantization_level_in_bits = kwargs.get('quantization_level_in_bits')
        self.com_encoder_mode = kwargs.get('com_encoder_mode')
        self.com_modulation_mode = kwargs.get('com_modulation_mode')
        self.comm_mode_inference = kwargs.get('comm_mode_inference')
        self.device = kwargs.get('device')
        self.action = kwargs.get('action')

        self.modulator = QPSK(**kwargs)
        SNR_mean = 10 ** (self.SNR_mean_in_dB / 10)
        self.random_SNR_producer = Exponential(1 / SNR_mean)
        self.SNR = self.random_SNR_producer.sample((self.batch_size,)).to(self.device)
        self.x_min = -1
        self.x_max = 1

    # ----------------------------------------------------------------------------
    # Transmission PART
    def transmit(self, x, is_retransmission=False):
        if self.action == 'train':
            return self.transmit_train(x, is_retransmission)
        else:
            return self.transmit_inference(x, is_retransmission)

    def transmit_train(self, x, is_retransmission=False):
        # input x: tensor
        # output y: tensor
        if self.com_channel_mode == 'AWGN':
            y, _ = self.AWGN(x, is_retransmission)
        else:
            y = x
        return y

    def transmit_inference(self, x, is_retransmission=False):
        if self.comm_mode_inference == 'Practical':
            x_modulated = self.modulator.modulate_fast(x).to(self.device)
            if self.com_channel_mode == 'AWGN':
                y, snr = self.AWGN(x_modulated, is_retransmission)
            else:
                y = x_modulated
                snr = None
            x_demodulated = self.modulator.demodulate_fast(y).to(self.device)
        elif self.comm_mode_inference == 'BSC':
            x_demodulated, snr = self.BSC_inference(x, is_retransmission)
        else:
            raise ValueError('please select comm_mode_inference as Practical or BSC.')
        return x_demodulated, snr

    def AWGN(self, x, is_retransmission=False):
        # input x: float tensor
        # output y: float tensor

        # x_rearranged0 = rearrange(x, 'a b c d -> a (b c d)')
        x_rearranged = x.view(x.shape[0], -1).to(self.device)
        required_shape = (x.shape[0],) + (1,) * (len(x.shape) - 1)
        x_norm = torch.norm(x_rearranged, dim=1)
        # reshape x_norm such that it can be used to normalize x

        if not is_retransmission:
            self.SNR = self.random_SNR_producer.sample((x.shape[0],)).to(self.device)

        # Caution: add_noise should be divided by the number of elements x_rearranged.shape[1] in each batch
        # this is because that, for each batch, torch.randn_like(x) will produce x_rearranged.shape[1] random numbers
        # each random number is sampled from a normal distribution with power (variance) of 1
        if 'complex' in str(x.dtype):
            noise_power_for_images = x_norm ** 2 / self.SNR
            noise_power_weight = (0.5 * noise_power_for_images / x_rearranged.shape[1]) ** 0.5
            # reshape noise_power_weight such that it can multiply with rand_like(x)
            noise_power_weight = noise_power_weight.clone().detach().reshape(required_shape)
            rand_real = torch.randn_like(x.real)
            rand_imag = torch.randn_like(x.imag)
            noise_real = noise_power_weight * rand_real
            noise_imag = noise_power_weight * rand_imag
            add_noise = torch.complex(noise_real, noise_imag)
            y = x + add_noise

            # the follow part results in the same y
            # noise_power_for_images = torch.ones((x.shape[0],)).to(self.device)
            # noise_power_weight = (0.5 * noise_power_for_images / x_rearranged.shape[1]) ** 0.5
            # # reshape noise_power_weight such that it can multiply with rand_like(x)
            # noise_power_weight = noise_power_weight.clone().detach().reshape(required_shape)
            # noise_real = noise_power_weight * rand_real
            # noise_imag = noise_power_weight * rand_imag
            # add_noise = torch.complex(noise_real, noise_imag)
            #
            # x = x / x_norm
            # transmit_power_for_images = self.SNR
            # transmit_power_weight = transmit_power_for_images ** 0.5
            # transmit_power_weight = transmit_power_weight.clone().detach().reshape(required_shape)
            # x_amplified_real = transmit_power_weight * x.real
            # x_amplified_imag = transmit_power_weight * x.imag
            # x_amplified = torch.complex(x_amplified_real, x_amplified_imag)
            #
            # y = (x_amplified + add_noise)*x_norm/transmit_power_weight

        else:
            noise_power_for_images = x_norm ** 2 / self.SNR
            noise_power_weight = (noise_power_for_images / x_rearranged.shape[1]) ** 0.5
            # reshape noise_power_weight such that it can multiply with rand_like(x)
            noise_power_weight = noise_power_weight.clone().detach().reshape(required_shape)

            y = x + noise_power_weight * torch.randn_like(x)

            y[y < 0] = 0.0
            num_of_bits = self.quantization_level_in_bits
            y[y > 2 ** num_of_bits - 1] = 2 ** num_of_bits - 1
        return y, self.SNR.unsqueeze(1).to(self.device)

    # ----------------------------------------------------------------------------
    # Encoding and Decoding PART, only for inference
    def encoding_inference(self, x_quantized):
        # input x_quantized: integer tensor
        # output x_binary_encoded: binary tensor
        if self.com_encoder_mode == 'NBC':
            # x_encoded_binary is in the form of tensor[[[[[0,0,0,1,1,1,0,0],...]], shape is (batch_size,256,2,2,bits)
            x_encoded_binary = int_2_binary(x=x_quantized, bits=self.quantization_level_in_bits)
        else:
            raise ValueError('com_encoder should be NBC. Please check it at encoding function in comm_modules.py')
        return x_encoded_binary.to(self.device)

    def decoding_inference(self, x_demodulated):
        binary_signal_flattened = x_demodulated.view(-1, x_demodulated.size(-1))
        # create decoded_signal with shape of B*C*H*W, 1
        decoded_signal = torch.zeros_like(binary_signal_flattened[:, 0])

        for i in range(binary_signal_flattened.size(-1)):
            decoded_signal += binary_signal_flattened[:, i] * (2 ** (binary_signal_flattened.size(-1) - i - 1))

        # reshape decoded_signal to B C H W
        decoded_signal = decoded_signal.view(x_demodulated.size()[:-1])

        return decoded_signal

    # ----------------------------------------------------------------------------
    # AD/DA part
    def ADC(self, x):
        # analog / digital converter
        # input x: float tensor
        # output x_quantized: integer tensor
        num_of_bits = self.quantization_level_in_bits
        if self.action == 'train':
            x_quantized = sin_round((x - self.x_min) / (self.x_max - self.x_min) * (2 ** num_of_bits - 1))
        else:
            x_quantized = torch.round((x - self.x_min) / (self.x_max - self.x_min) * (2 ** num_of_bits - 1))
        return x_quantized

    def DAC(self, x):
        # Digital to analog converter
        # input x:
        num_of_bits = self.quantization_level_in_bits
        x_analog = (self.x_max - self.x_min) / (2 ** num_of_bits - 1) * x + self.x_min
        return x_analog.to(self.device)

    # ----------------------------------------------------------------------
    # some auxiliary functions
    def BSC_inference(self, input_bits, is_retransmission=False):
        """
        transmit data through a binary symmetric channel
        Args:
        - input_bits: binary tensor in shape of B C W H Q
        Returns:
        - output_bits: binary tensor in shape of B C W H Q
        """
        if not is_retransmission:
            self.SNR = self.random_SNR_producer.sample((input_bits.shape[0],))
        error_prob = self.BEP_for_BSC(self.SNR)
        # reshaple error_prob from tensor([B]) to tensor([B,1,1,1,1])
        shape_required = input_bits.shape[:len(error_prob.shape)] + (1,) * (
                len(input_bits.shape) - len(error_prob.shape))
        # obtain error_prob_expand in shape of input_bits
        error_prob_expand = error_prob.view(shape_required).expand_as(input_bits)
        flip_mask = (torch.rand(input_bits.shape) < error_prob_expand).int()
        output_bits = (input_bits + flip_mask) % 2
        return output_bits, self.SNR.unsqueeze(1).to(self.device)

    def BEP_for_BSC(self, SNR):
        if self.com_modulation_mode == 'QPSK':
            bep = Q_function(SNR)
        elif self.com_modulation_mode == 'BPSK':
            bep = Q_function(2 * SNR)
        else:
            raise ValueError('com_modulation should be QPSK or BPSK. Please check it at encoding function in '
                             'comm_modules.py')
        return bep


class QPSK:
    def __init__(self, **kwargs):
        self.com_modulation = kwargs.get('com_modulation_infer')
        self.device = kwargs.get('device')
        self.batch_size = kwargs.get('batch_size')
        self.quantization_level_in_bits = kwargs.get('quantization_level_in_bits')
        self.data_shape = kwargs.get('data_shape')
        self.constellation = self.generate_constel()

    def generate_constel(self):
        constellation = torch.tensor([1 + 1j, -1 + 1j, -1 - 1j, 1 - 1j], dtype=torch.complex64)
        return constellation.to(self.device)

    def modulate_fast(self, x):
        flattened_data = x.view(-1, 2)

        symbol_indices = flattened_data[:, 0] * 2 + flattened_data[:, 1]

        symbols = self.constellation[symbol_indices.long()]

        output_shape = x.shape[0:-1] + (int(x.shape[-1] / 2),)
        symbols = symbols.view(tuple(output_shape))
        return symbols

    def demodulate_fast(self, x):

        distances = torch.abs(x.unsqueeze(-1) - self.constellation.unsqueeze(0))

        symbol_indices = torch.argmin(distances, dim=-1)

        demodulated_data = torch.stack([torch.div(symbol_indices, 2, rounding_mode='floor'), symbol_indices % 2],
                                       dim=-1)

        output_shape = x.shape[0:-1] + (int(x.shape[-1] * 2),)
        decoded_data = demodulated_data.view(output_shape)
        return decoded_data