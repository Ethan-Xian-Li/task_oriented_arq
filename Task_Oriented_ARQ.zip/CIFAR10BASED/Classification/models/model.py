# import sys
# sys.path.append('D:/XianLi/WSMEC/Task_Oriented_ARQ/CIFAR10BASED')

from models.sub_modules import BasicMLPBlock, BasicMLPBlockARQ
from models.comm_modules import WirelessComm

import torch
import torch.nn as nn


class MNISTClassifierMLP(nn.Module):
    def __init__(self, **kwargs):
        super().__init__()
        CLF_intput_size_mlp = kwargs.get('CLF_intput_size_mlp')
        number_of_classes = kwargs.get('number_of_classes')
        CLF_hidden_sizes_mlp = kwargs.get('CLF_hidden_sizes_mlp')
        FE_hidden_sizes_mlp = kwargs.get('FE_hidden_sizes_mlp')
        C, H, W = kwargs.get('data_shape')

        self.feature_extractor = BasicMLPBlock(input_size=C * W * H,
                                               hidden_sizes=FE_hidden_sizes_mlp,
                                               output_size=CLF_intput_size_mlp)

        self.classifier0 = BasicMLPBlock(input_size=CLF_intput_size_mlp,
                                         hidden_sizes=CLF_hidden_sizes_mlp,
                                         output_size=number_of_classes)

        self.classifier1 = BasicMLPBlock(input_size=CLF_intput_size_mlp * 2,
                                         hidden_sizes=CLF_hidden_sizes_mlp,
                                         output_size=number_of_classes)
        self.activation = nn.Tanh()

        self.data_communication = WirelessComm(**kwargs)

    def forward(self, x):
        x = x.flatten(start_dim=1)
        x = self.feature_extractor(x)
        x = self.activation(x)

        # ------quantization and wireless transmission-------#
        # quantization
        x = self.data_communication.ADC(x)
        # data transmission
        x_tran = self.data_communication.transmit(x=x, is_retransmission=False)
        # data de-quantization
        x_tran = self.data_communication.DAC(x=x_tran)
        # retransmission
        x_retran = self.data_communication.transmit(x=x, is_retransmission=True)
        # data de-quantization
        x_retran = self.data_communication.DAC(x=x_retran)
        # ----------------------------------------------------#
        x0 = x_tran
        output0 = self.classifier0(x0)

        x1 = torch.cat((x_tran, x_retran), dim=1)
        output1 = self.classifier1(x1)

        return output0, output1


class MNISTARQDecisionMaker(nn.Module):
    def __init__(self, **kwargs):
        super().__init__()
        ARQ_mlp_hidden_sizes = kwargs.get('ARQ_mlp_hidden_sizes')
        ARQ_output_size = kwargs.get('ARQ_output_size')
        input_size = 1 + 1

        self.decision_maker = BasicMLPBlockARQ(input_size=input_size,
                                               hidden_sizes=ARQ_mlp_hidden_sizes, output_size=ARQ_output_size)
        # when output_size=2, using softmax; when output_size=1, using sigmoid
        # self.activation = nn.LogSoftmax(dim=1)
        self.temperature = 1

    def forward(self, ARQ_input):
        
        ARQ_output = self.decision_maker(ARQ_input)
        
        ARQ_output = ARQ_output/self.temperature
        
        return ARQ_output


if __name__ == '__main__':
    from configs.configs import create_argparser

    configs = create_argparser().parse_args()
    model = MNISTClassifierMLP(**vars(configs))
    print(model)

