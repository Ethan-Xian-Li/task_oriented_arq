import torch.nn as nn


class BasicMLPBlock(nn.Module):
    def __init__(self, input_size: int, hidden_sizes: tuple, output_size: int):
        super(BasicMLPBlock, self).__init__()
        self.hidden_layers = nn.ModuleList()
        self.activation = nn.SELU()

        if len(hidden_sizes) >= 1:
            for i in range(len(hidden_sizes)):
                self.hidden_layers.append(nn.Linear(input_size, hidden_sizes[i]))
                self.hidden_layers.append(self.activation)
                self.hidden_layers.append(nn.BatchNorm1d(hidden_sizes[i]))
                input_size = hidden_sizes[i]

            self.output_layer = nn.Linear(hidden_sizes[-1], output_size)
        else:
            self.output_layer = nn.Linear(input_size, output_size)


    def forward(self, x):
        for i, layer in enumerate(self.hidden_layers):
            x = layer(x)

        y = self.output_layer(x)
        return y


class BasicMLPBlockARQ(nn.Module):
    def __init__(self, input_size: int, hidden_sizes: tuple, output_size: int):
        super(BasicMLPBlockARQ, self).__init__()
        self.hidden_layers = nn.ModuleList()

        self.activation = nn.ReLU()
        if len(hidden_sizes) >= 1:
            for i in range(len(hidden_sizes)):
                self.hidden_layers.append(nn.Linear(input_size, hidden_sizes[i]))
                self.hidden_layers.append(self.activation)
                self.hidden_layers.append(nn.BatchNorm1d(hidden_sizes[i]))
                self.hidden_layers.append(nn.Dropout(p=0.8))
                input_size = hidden_sizes[i]

            self.output_layer = nn.Linear(hidden_sizes[-1], output_size)
        else:
            self.output_layer = nn.Linear(input_size, output_size)

    def forward(self, x):
        for i, layer in enumerate(self.hidden_layers):
            x = layer(x)

        y = self.output_layer(x)
        return y

