import argparse
import random
import numpy as np
from numpy.random import MT19937
from numpy.random import RandomState, SeedSequence
import torch
import torch.backends.cudnn
import torch.cuda


def set_determenistic_mode(SEED, disable_cudnn=False):
    torch.manual_seed(SEED)  # Seed the RNG for all devices (both CPU and CUDA).
    random.seed(SEED)  # Set python seed for custom operators.
    rs = RandomState(
        MT19937(SeedSequence(SEED)))  # If any of the libraries or code rely on NumPy seed the global NumPy RNG.
    np.random.seed(SEED)
    torch.cuda.manual_seed(SEED)  # If you are using multi-GPU. In case of one GPU, you can use #
    # torch.cuda.manual_seed(SEED).

    if not disable_cudnn:
        torch.backends.cudnn.benchmark = False  # Causes cuDNN to deterministically select an algorithm,
        # possibly at the cost of reduced performance
        # (the algorithm itself may be nondeterministic).
        torch.backends.cudnn.deterministic = True  # Causes cuDNN to use a deterministic convolution algorithm,
        # but may slow down performance.
        # It will not guarantee that your training process is deterministic
        # if you are using other libraries that may use nondeterministic algorithms
    else:
        torch.backends.cudnn.enabled = False  # Controls whether cuDNN is enabled or not.
        # If you want to enable cuDNN, set it to True.


def create_argparser():
    # --------------------------------------------------------#
    # path: the path for saving dataset, checkpoint, and log
    # task: CFL or ARQ
    # action: train, test, datagen
    # dataset: the used dataset, in str
    # lr: learning rate
    # batch_size: the training batch size
    # training_epochs: the total training epochs
    # number_of_snr_each_sample: we sample 100 snr's in default for each CIFAR data
    # early_stop_patience: threshold for early quit, unit:epochs
    # optimizer: the used optimizer for updating DNN parameters
    # weight_decay: the weight decay value in optimizer
    # scheduler: the training scheduler, Step or Reduce
    # criterion: the criterion for computing loss
    # resume_checkpoint: the path of checkpoint
    # device: the device used for training
    # log_level: "DEBUG", "INFO", "WARNING", "ERROR"
    # --------------------------------------------------------#
    defaults = dict(
        path="E:/Task_Oriented_ARQ/CIFAR10BASED/Classification/",
        task='CLF',
        action='train',
        dataset="MNIST",
        data_shape=(1, 28, 28),
        lr=1e-3,
        batch_size=256,
        training_epochs=5000,
        number_of_snr_each_sample=1,
        number_of_retrans_each_sample=100,
        early_stop_patience=20,
        optimizer='Adam',
        weight_decay=1e-4,
        scheduler='Step',
        lr_factor=0.1,
        patience=10,
        criterion_CLF='CE',
        criterion_ARQ='CE',
        resume_checkpoint=False,
        device='cpu',
        log_level='INFO',
        random_seed=3407,
    )

    # --------------------------------------------------------#
    # CLF model exploits MLP module in FetureExtrator, and MLP in Classifier(reconstructor)
    # FE_hidden_sizes_mlp: the hidden layers in FetureExtrator
    # FE_mlp_output_size: the output of FetureExtrator, determining the compress ratio
    # CLF_mlp_hidden_sizes: the hidden layers in Classifier
    # number_of_classes: the output of CIFAR10_CLF
    # --------------------------------------------------------#
    CLF_model_params_mnist10 = dict(
        type_of_model='mlp',
        number_of_classes=10,
        FE_hidden_sizes_mlp=(2048, 512, 128),
        CLF_intput_size_mlp=16,
        CLF_hidden_sizes_mlp=(256, 128),
    )

    # --------------------------------------------------------#
    # ARQ model exploits a BasicMLPBlock module
    # ARQ_mlp_hidden_sizes: tuple, the number of neurons in hidden layers
    # ARQ_output_size: int, the outsize of ARQ
    # --------------------------------------------------------#

    ARQ_model_params_mnist10 = dict(
        ARQ_mlp_hidden_sizes=(256, 4,),
        ARQ_output_size=2,
    )

    # --------------------------------------------------------#
    # communication model parameters
    # wirelesscom_channel_mode: 'AWGN', None
    # comm_mode_inference: 'Practical', 'BSC'. for inference only
    # quantization_level_in_bits: the quantization bits for each continuous neuron output
    # SNR_in_dB: default SNR for training IR model
    # delay_weight: default weighting factor for training ARQ model
    # com_encoder_mode: NBC (natural binary code)
    # com_modulation_mode: QPSK
    # --------------------------------------------------------#
    comm_params = dict(
        wirelesscom_channel_mode='AWGN',
        comm_mode_inference='Practical',
        com_encoder_mode='NBC',
        com_modulation_mode='QPSK',
        quantization_level_in_bits=4,
        SNR_mean_in_dB=3,
        delay_weight=8,
        delay=0.01,
    )

    defaults.update(CLF_model_params_mnist10)
    defaults.update(comm_params)
    defaults.update(ARQ_model_params_mnist10)
    parser = argparse.ArgumentParser()
    add_dict_to_argparser(parser, defaults)
    return parser


def add_dict_to_argparser(parser, default_dict):
    for k, v in default_dict.items():
        v_type = type(v)
        if isinstance(v, tuple):
            v_type = int
            parser.add_argument(f"--{k}", nargs='+', default=v, type=v_type, action=TupleAction)
            continue
        elif v is None:
            v_type = str
        elif isinstance(v, bool):
            v_type = str2bool
        parser.add_argument(f"--{k}", default=v, type=v_type)


class TupleAction(argparse.Action):
    def __call__(self, parser, namespace, values, option_string=None):
        setattr(namespace, self.dest, tuple(values))


def str2bool(v):
    """
    https://stackoverflow.com/questions/15008758/parsing-boolean-values-with-argparse
    """
    if isinstance(v, bool):
        return v
    if v.lower() in ("yes", "true", "t", "y", "1"):
        return True
    elif v.lower() in ("no", "false", "f", "n", "0"):
        return False
    else:
        raise argparse.ArgumentTypeError("boolean value expected")
