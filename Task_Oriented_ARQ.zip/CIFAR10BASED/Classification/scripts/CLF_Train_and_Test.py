import torch
import torch.nn as nn
import os
from tqdm import tqdm
from util.losses import Optimizer, Scheduler, Criterion
from util.utils import AvgMeter, ser_in_average
from util.dataprocess import (
    get_dataloader,
    model_loder,
    model_saver,
)
from util.logger import Logger
from util.metrics import EvaluationMetrics
from models.comm_modules import WirelessComm
from datetime import datetime

calendar = datetime.now()
year, month, day = calendar.year, calendar.month, calendar.day


class CLFTrainer:
    def __init__(self, model, configs):
        self.number_of_snr_each_sample = configs.number_of_snr_each_sample
        self.log_path = os.path.join(configs.path,
                                     'log/{}/{}/snr{}_{}fe_{}bits/'.format(
                                         configs.dataset,
                                         configs.task,
                                         configs.SNR_mean_in_dB,
                                         configs.CLF_intput_size_mlp,
                                         configs.quantization_level_in_bits))
        self.checkpoint_path = os.path.join(configs.path,
                                            'results/checkpoint/CLF/snr{}_{}fe_{}bits/'.format(
                                                configs.SNR_mean_in_dB,
                                                configs.CLF_intput_size_mlp,
                                                configs.quantization_level_in_bits))
        os.makedirs(self.log_path, exist_ok=True)
        os.makedirs(self.checkpoint_path, exist_ok=True)

        self.device = configs.device
        self.model = model.to(self.device)

        self.criterion = Criterion(criterion=configs.criterion_CLF)
        self.optimizer = Optimizer(args=configs, model=self.model)
        self.scheduler = Scheduler(args=configs, optimizer=self.optimizer)

        self.logger = Logger(self.log_path + 'log_{}_{}_{}.txt'.format(year, month, day), configs)
        args_data = ' '.join([f'{key}: {value},\n' for key, value in vars(configs).items()])
        self.logger.log(args_data)

        self.logger.log('{} Classification model training...'.format(configs.dataset))
        if configs.resume_checkpoint:
            loaded_epoch, min_loss, model_name = model_loder(model=self.model,
                                                             task=configs.task,
                                                             optimizer=self.optimizer,
                                                             scheduler=self.scheduler,
                                                             path=self.checkpoint_path,
                                                             configs=configs,
                                                             load_schedule=True)
            self.logger.log("Resuming from an checkpoint {} from {}.".format(model_name, self.checkpoint_path))
        else:
            loaded_epoch = 0
            min_loss = 10000

        self.train_loader, self.val_loader = get_dataloader(configs=configs)
        self.evaluator = EvaluationMetrics(configs=configs)

        epoch_save_checkpoint = loaded_epoch
        early_stopping = 0
        for epoch in tqdm(range(loaded_epoch, configs.training_epochs)):
            self.epoch = epoch
            train_loss = self.training()
            val_loss, val_accurate0, val_accurate1 = self.validate()
            self.logger.log('Epoch {}, training CE loss {}, val_loss {}, val_acc_wo {}, '
                            'val_acc_w {}'.format(epoch, train_loss, val_loss, val_accurate0, val_accurate1))

            if configs.scheduler == 'Reduce':
                self.scheduler.step(val_loss)
            else:
                self.scheduler.step()

            # Save models
            if val_loss < min_loss:
                min_loss = val_loss
                epoch_save_checkpoint = epoch
                early_stopping = 0
                model_saver(epoch=epoch, min_loss=min_loss, model=self.model, optimizer=self.optimizer,
                            scheduler=self.scheduler, path=self.checkpoint_path, configs=configs)
            else:
                early_stopping += 1

            if early_stopping == configs.early_stop_patience:
                break

        self.logger.log('Latest CLF checkpoint at epoch {} with val_loss {}'.format(epoch_save_checkpoint, min_loss))
        self.logger.log('The model is saved at {}'.format(self.checkpoint_path))
        self.logger.log('------------------End time: {}---------------------\n'.format(datetime.now()))

    def training(self):
        self.model.train()
        train_loss = AvgMeter()

        for image, label in self.train_loader:
            image = image.to(self.device)
            label = label.to(self.device)

            repeat_shape = (self.number_of_snr_each_sample,) + (1,) * (len(image.shape) - 1)
            image_repeat = image.repeat(repeat_shape)
            label_repeat = label.repeat(self.number_of_snr_each_sample)
            self.optimizer.zero_grad()
            output_wo_retrans, output_w_retrans = self.model(image_repeat)
            loss0 = self.criterion(output_wo_retrans, label_repeat)
            loss1 = self.criterion(output_w_retrans, label_repeat)
            loss = loss0 + loss1

            loss.backward()
            # clip_grad_norm_ 防止梯度爆炸
            # nn.utils.clip_grad_norm_(self.model.parameters(), 5.0)
            self.optimizer.step()

            train_loss.update(loss.item(), n=image_repeat.size(0))
        return train_loss.avg

    def validate(self):
        self.model.eval()
        val_loss = AvgMeter()
        val_accuracy0 = AvgMeter()
        val_accuracy1 = AvgMeter()
        with torch.no_grad():
            for image, label in self.val_loader:
                image = image.to(self.device)
                label = label.to(self.device)

                repeat_shape = (self.number_of_snr_each_sample,) + (1,) * (len(image.shape) - 1)
                image_repeat = image.repeat(repeat_shape)
                label_repeat = label.repeat(self.number_of_snr_each_sample)
                output_wo_retrans, output_w_retrans = self.model(image_repeat)
                loss0 = self.criterion(output_wo_retrans, label_repeat)
                loss1 = self.criterion(output_w_retrans, label_repeat)
                loss = loss0 + loss1
                val_loss.update(loss.item(), n=image_repeat.size(0))

                num_of_accurate0 = self.evaluator.correct_set(label=label_repeat, predicted=output_wo_retrans)
                num_of_accurate1 = self.evaluator.correct_set(label=label_repeat, predicted=output_w_retrans)
                val_accuracy0.update(num_of_accurate0.sum().item(), n=image_repeat.size(0))
                val_accuracy1.update(num_of_accurate1.sum().item(), n=image_repeat.size(0))

        return val_loss.avg, val_accuracy0.avg, val_accuracy1.avg


class CLFTester:
    def __init__(self, model, configs):
        self.number_of_snr_each_sample = configs.number_of_snr_each_sample
        self.log_path = os.path.join(configs.path,
                                     'log/{}/{}/snr{}_{}fe_{}bits/'.format(
                                         configs.dataset,
                                         configs.task,
                                         configs.SNR_mean_in_dB,
                                         configs.CLF_intput_size_mlp,
                                         configs.quantization_level_in_bits))
        self.checkpoint_path = os.path.join(configs.path,
                                            'results/checkpoint/CLF/snr{}_{}fe_{}bits/'.format(
                                                configs.SNR_mean_in_dB,
                                                configs.CLF_intput_size_mlp,
                                                configs.quantization_level_in_bits))
        os.makedirs(self.log_path, exist_ok=True)
        os.makedirs(self.checkpoint_path, exist_ok=True)

        self.criterion = Criterion(criterion=configs.criterion_CLF)
        self.data_communication = WirelessComm(**vars(configs))

        self.logger = Logger(self.log_path + 'log_{}_{}_{}.txt'.format(year, month, day), configs)
        self.logger.log('{} Classification model testing... Feature size: {} neurons, quantization: {} bits'.format(
            configs.dataset, configs.CLF_intput_size_mlp, configs.quantization_level_in_bits))

        self.device = configs.device
        _, _, model_name = model_loder(model=model, task=configs.task, path=self.checkpoint_path, configs=configs)
        self.logger.log('Loading an existing CLF model {} for test from {}'.format(model_name,
                                                                                   self.checkpoint_path))
        self.model = model.to(self.device)

        self.test_loader, _ = get_dataloader(configs=configs)

        self.evaluator = EvaluationMetrics(configs=configs)
        self.test()

    def test(self):
        # Eval_tool = Evaluation_metrics(self.configs)
        self.model.eval()
        test_loss = AvgMeter()
        test_accuracy0 = AvgMeter()
        test_accuracy1 = AvgMeter()
        with torch.no_grad():
            for i, (image, label) in tqdm(enumerate(self.test_loader)):
                image = image.to(self.device)
                label = label.to(self.device)

                repeat_shape = (self.number_of_snr_each_sample,) + (1,) * (len(image.shape) - 1)
                image_repeat = image.repeat(repeat_shape)
                label_repeat = label.repeat(self.number_of_snr_each_sample)

                # reconstructed_image0, reconstructed_image1 = self.model(image)
                x = image_repeat.flatten(start_dim=1)
                x_feature = self.model.feature_extractor(x)
                x_feature = self.model.activation(x_feature)

                x_quantized = self.data_communication.ADC(x_feature)
                x_encoded = self.data_communication.encoding_inference(x_quantized)

                x_received0, _ = self.data_communication.transmit(x=x_encoded, is_retransmission=False)
                x_decoded0 = self.data_communication.decoding_inference(x_received0)
                # Symbol_error_rate = ser_in_average(x_quantized, x_decoded0)
                x_dequantized0 = self.data_communication.DAC(x_decoded0)

                x_received1, _ = self.data_communication.transmit(x=x_encoded, is_retransmission=True)
                x_decoded1 = self.data_communication.decoding_inference(x_received1)
                x_dequantized1 = self.data_communication.DAC(x_decoded1)

                output_wo_retrans = self.model.classifier0(x_dequantized0)
                x_dequantized0and1 = torch.cat((x_dequantized0, x_dequantized1), dim=1)
                output_w_retrans = self.model.classifier1(x_dequantized0and1)

                loss0 = self.criterion(output_wo_retrans, label_repeat)
                loss1 = self.criterion(output_w_retrans, label_repeat)
                loss = loss0 + loss1

                num_of_accurate0 = self.evaluator.correct_set(label=label_repeat, predicted=output_wo_retrans)
                num_of_accurate1 = self.evaluator.correct_set(label=label_repeat, predicted=output_w_retrans)

                test_loss.update(loss.item(), n=image_repeat.size(0))
                test_accuracy0.update(num_of_accurate0.sum().item(), n=image_repeat.size(0))
                test_accuracy1.update(num_of_accurate1.sum().item(), n=image_repeat.size(0))
        self.logger.log('Test CE loss: {}.'.format(test_loss.avg))
        self.logger.log('w/o retransmission: acc is {}'.format(test_accuracy0.avg))
        self.logger.log('with retransmission: acc is {}'.format(test_accuracy1.avg))
