import torch
import os
from tqdm import tqdm
from util.losses import Optimizer, Scheduler, Criterion
from util.utils import AvgMeter, arq_crc_decision
from util.resultplot import result_save
from util.dataprocess import (
    get_dataloader,
    model_loder,
    model_saver,
    ARQ_data_process
)
from util.logger import Logger
from util.metrics import EvaluationMetrics
from models.comm_modules import WirelessComm
from datetime import datetime


calendar = datetime.now()
year, month, day = calendar.year, calendar.month, calendar.day


class ARQTrainer:
    def __init__(self, ARQ_model, configs):
        self.configs = configs
        self.number_of_snr_each_sample = configs.number_of_snr_each_sample
        self.log_path = os.path.join(configs.path,
                                     'log/{}/{}/snr{}_{}fe_{}bits_weight{}/'.format(
                                         configs.dataset,
                                         configs.task,
                                         configs.SNR_mean_in_dB,
                                         configs.CLF_intput_size_mlp,
                                         configs.quantization_level_in_bits,
                                         self.configs.delay_weight))

        # self.delay_weight_str = str(configs.delay_weight).replace('.', '_')
        self.ARQ_checkpoint_path = os.path.join(configs.path,
                                                'results/checkpoint/ARQ/snr{}_{}fe_{}bits_weight{}/'.format(
                                                    configs.SNR_mean_in_dB,
                                                    configs.CLF_intput_size_mlp,
                                                    configs.quantization_level_in_bits,
                                                    self.configs.delay_weight))

        os.makedirs(self.log_path, exist_ok=True)
        os.makedirs(self.ARQ_checkpoint_path, exist_ok=True)

        self.logger = Logger(self.log_path + 'log_{}_{}_{}.txt'.format(year, month, day), configs)
        args_data = ' '.join([f'{key}: {value},\n' for key, value in vars(configs).items()])
        self.logger.log(args_data)
        self.logger.log('ARQ model training...')

        self.device = configs.device
        self.ARQ_model = ARQ_model.to(self.device)

        self.train_loader, self.val_loader = get_dataloader(configs=configs)
        self.criterion = Criterion(criterion=configs.criterion_ARQ)
        self.optimizer = Optimizer(args=configs, model=self.ARQ_model)
        self.scheduler = Scheduler(args=configs, optimizer=self.optimizer)

        if configs.resume_checkpoint:
            self.loaded_epoch, self.min_loss, ARQ_model_name = model_loder(model=self.ARQ_model,
                                                                           task='ARQ',
                                                                           optimizer=self.optimizer,
                                                                           scheduler=self.scheduler,
                                                                           path=self.ARQ_checkpoint_path,
                                                                           configs=configs,
                                                                           load_schedule=True)
            self.logger.log('Resuming from an existing ARQ checkpoint {} from {}.'.format(ARQ_model_name,
                                                                                          self.ARQ_checkpoint_path))
        else:
            self.loaded_epoch = 0
            self.min_loss = 10000

        self.evaluator = EvaluationMetrics(configs=configs)
        self.data_communication = WirelessComm(**vars(configs))

        self.training()

    def training(self):
        min_loss = self.min_loss
        epoch_save_checkpoint = self.loaded_epoch
        early_stopping = 0
        for epoch in tqdm(range(self.loaded_epoch, self.configs.training_epochs)):
            train_loss = self.train_one_epoch()
            val_loss, val_acc = self.validate()
            self.logger.log('Epoch {}, training MSE loss {}, val_loss {},'
                            ' val_acc {}'.format(epoch, train_loss, val_loss, val_acc))

            if self.configs.scheduler == 'Reduce':
                self.scheduler.step(val_loss)
            else:
                self.scheduler.step()

            # Save models
            if val_loss < min_loss:
                min_loss = val_loss
                epoch_save_checkpoint = epoch
                early_stopping = 0
                model_saver(epoch=epoch, min_loss=min_loss, model=self.ARQ_model, optimizer=self.optimizer,
                            scheduler=self.scheduler, path=self.ARQ_checkpoint_path, configs=self.configs)
            else:
                early_stopping += 1

            if early_stopping == self.configs.early_stop_patience:
                break

        self.logger.log(
            'The best ARQ checkpoint is at epoch {} with val_loss {}'.format(epoch_save_checkpoint, min_loss))
        self.logger.log('The model is saved at {}'.format(self.ARQ_checkpoint_path))
        self.logger.log('------------------End time: {}---------------------\n'.format(datetime.now()))

    def train_one_epoch(self):
        self.ARQ_model.train()
        train_loss = AvgMeter()

        for train_data in self.train_loader:
            output_wo_retrans = train_data['output_wo_retrans'].to(self.device)
            snr = train_data['snr'].to(self.device)
            AQR_decision_label = train_data['AQR_decision_label'].to(self.device)

            # ARQ data processing
            ARQ_input = ARQ_data_process(x=output_wo_retrans, snr=snr)

            ARQ_output = self.ARQ_model(ARQ_input=ARQ_input)
            # AQR_decision_label = AQR_decision_label.squeeze()
            # ARQ_output = ARQ_output.squeeze()
            AQR_decision_label = AQR_decision_label.to(torch.int64)
            loss = self.criterion(ARQ_output, AQR_decision_label)

            # plot_scatter(ARQ_output, AQR_decision_label)

            self.optimizer.zero_grad()
            loss.backward()
            # clip_grad_norm_ 防止梯度爆炸
            # nn.utils.clip_grad_norm_(self.model.parameters(), args.clipping)
            self.optimizer.step()

            train_loss.update(loss.item(), n=snr.size(0))
        return train_loss.avg

    def validate(self):
        self.ARQ_model.eval()
        val_loss = AvgMeter()
        val_correct_num = AvgMeter()
        with torch.no_grad():
            for val_data in self.val_loader:
                output_wo_retrans = val_data['output_wo_retrans'].to(self.device)
                snr = val_data['snr'].to(self.device)
                AQR_decision_label = val_data['AQR_decision_label'].to(self.device)

                ARQ_input = ARQ_data_process(x=output_wo_retrans, snr=snr)

                ARQ_output = self.ARQ_model(ARQ_input=ARQ_input)

                AQR_decision_label = AQR_decision_label.to(torch.int64)
                loss = self.criterion(ARQ_output, AQR_decision_label)
                val_loss.update(loss.item(), n=snr.size(0))

                num_of_accurate = self.evaluator.correct_set(label=AQR_decision_label, predicted=ARQ_output)
                val_correct_num.update(num_of_accurate.sum().item(), n=output_wo_retrans.size(0))
        return val_loss.avg, val_correct_num.avg


class ARQTester:
    def __init__(self, ARQ_model, CLF_model, configs):
        self.configs = configs
        self.number_of_snr_each_sample = configs.number_of_snr_each_sample
        self.log_path = os.path.join(configs.path,
                                     'log/{}/{}/snr{}_{}fe_{}bits_weight{}/'.format(
                                         configs.dataset,
                                         configs.task,
                                         configs.SNR_mean_in_dB,
                                         configs.CLF_intput_size_mlp,
                                         configs.quantization_level_in_bits,
                                         self.configs.delay_weight))

        # self.delay_weight_str = str(configs.delay_weight).replace('.', '_')
        self.ARQ_checkpoint_path = os.path.join(configs.path,
                                                'results/checkpoint/ARQ/snr{}_{}fe_{}bits_weight{}/'.format(
                                                    configs.SNR_mean_in_dB,
                                                    configs.CLF_intput_size_mlp,
                                                    configs.quantization_level_in_bits,
                                                    self.configs.delay_weight))

        self.CLF_checkpoint_path = os.path.join(configs.path,
                                                'results/checkpoint/CLF/snr{}_{}fe_{}bits/'.format(
                                                    configs.SNR_mean_in_dB,
                                                    configs.CLF_intput_size_mlp,
                                                    configs.quantization_level_in_bits))

        os.makedirs(self.log_path, exist_ok=True)
        os.makedirs(self.ARQ_checkpoint_path, exist_ok=True)
        os.makedirs(self.CLF_checkpoint_path, exist_ok=True)

        self.logger = Logger(self.log_path + 'log_{}_{}_{}.txt'.format(year, month, day), configs)
        args_data = ' '.join([f'{key}: {value},\n' for key, value in vars(configs).items()])
        self.logger.log(args_data)
        self.logger.log('ARQ model testing...')

        self.device = configs.device
        self.ARQ_model = ARQ_model.to(self.device)
        self.CLF_model = CLF_model.to(self.device)

        _, _, model_name = model_loder(model=self.ARQ_model, task='ARQ', path=self.ARQ_checkpoint_path, configs=configs)
        self.logger.log('Loading an existing ARQ model {} for test from {}'.format(model_name,
                                                                                   self.ARQ_checkpoint_path))

        _, _, _CLF_model_name = model_loder(model=self.CLF_model, task='CLF',
                                            path=self.CLF_checkpoint_path, configs=configs)

        self.logger.log('Loading an existing CLF model {} from {}'.format(_CLF_model_name, self.CLF_checkpoint_path))

        self.test_loader, _ = get_dataloader(configs=configs)
        self.evaluator = EvaluationMetrics(configs=configs)
        self.criterion = Criterion(criterion=configs.criterion_ARQ)
        self.data_communication = WirelessComm(**vars(configs))

        self.test()

    def test(self):
        # Eval_tool = Evaluation_metrics(self.configs)
        self.ARQ_model.eval()
        self.CLF_model.eval()
        test_loss = AvgMeter()
        test_ARQ_correct_num = AvgMeter()
        test_CLF_correct_num = AvgMeter()
        test_ARQ_delay = AvgMeter()
        test_one_shot_delay = AvgMeter()
        test_one_shot_CLF_correcet = AvgMeter()
        test_always_retrans_delay = AvgMeter()
        test_always_retrans_CLF_correcet = AvgMeter()
        test_crc_based_CLF_correct_num = AvgMeter()
        test_crc_based_delay = AvgMeter()
        with torch.no_grad():
            for image, label in tqdm(self.test_loader):
                image = image.to(self.device)
                img_label = label.to(self.device)

                repeat_shape = (self.number_of_snr_each_sample,) + (1,) * (len(image.shape) - 1)
                image_repeat = image.repeat(repeat_shape)
                label_repeat = img_label.repeat(self.number_of_snr_each_sample)

                x = image_repeat.flatten(start_dim=1)
                x_feature = self.CLF_model.feature_extractor(x)
                x_feature = self.CLF_model.activation(x_feature)

                x_quantized = self.data_communication.ADC(x_feature)
                x_transmitted_binary = self.data_communication.encoding_inference(x_quantized)

                x_recovered_binary0, snr = self.data_communication.transmit(x=x_transmitted_binary,
                                                                            is_retransmission=False)
                x_decoded0 = self.data_communication.decoding_inference(x_recovered_binary0)
                x_dequantized0 = self.data_communication.DAC(x_decoded0)

                output_wo_retrans = self.CLF_model.classifier0(x_dequantized0)
                score0, loss0, delay0, CLF_correct_set0 = self.evaluator.arq_score(is_retransmission=False,
                                                                                       image_label=label_repeat,
                                                                                       predict=output_wo_retrans)

                x_recovered_binary1, snr = self.data_communication.transmit(x=x_transmitted_binary,
                                                                            is_retransmission=True)
                x_decoded1 = self.data_communication.decoding_inference(x_recovered_binary1)
                x_dequantized1 = self.data_communication.DAC(x_decoded1)

                x_dequantized0and1 = torch.cat((x_dequantized0, x_dequantized1), dim=1)
                output_w_retrans = self.CLF_model.classifier1(x_dequantized0and1)

                score1, loss1, delay1, CLF_correct_set1 = self.evaluator.arq_score(is_retransmission=True,
                                                                                       image_label=label_repeat,
                                                                                       predict=output_w_retrans)

                AQR_decision_label = self.ARQ_label_producer(x_encoded=x_transmitted_binary,
                                                             x_dequantized0=x_dequantized0,
                                                             score0=score0,
                                                             CLF_label=label_repeat)
                # AQR_decision_label here is used to test the ARQ decision accuracy
                AQR_decision_label = AQR_decision_label.to(torch.int64)

                # evaluate the classification and delay performance of Semantic-ARQ
                ARQ_input = ARQ_data_process(x=output_wo_retrans, snr=snr)
                ARQ_output = self.ARQ_model(ARQ_input=ARQ_input)
                ARQ_decision_predict = torch.max(ARQ_output.data, 1)[1].data
                CLF_correct_set = ARQ_decision_predict * CLF_correct_set1 + (
                        1 - ARQ_decision_predict) * CLF_correct_set0
                ARQ_delay = ARQ_decision_predict*delay1 + (1 - ARQ_decision_predict)*delay0

                test_CLF_correct_num.update(CLF_correct_set.sum().item(), n=output_wo_retrans.size(0))
                test_ARQ_delay.update(ARQ_delay.sum().item(), n=output_wo_retrans.size(0))

                loss = self.criterion(ARQ_output, AQR_decision_label)
                test_loss.update(loss.item(), n=output_wo_retrans.size(0))

                ARQ_num_of_accurate = self.evaluator.correct_set(label=AQR_decision_label, predicted=ARQ_output)
                test_ARQ_correct_num.update(ARQ_num_of_accurate.sum().item(), n=output_wo_retrans.size(0))

                # evaluate the classification and delay performance of one-shot transmission
                test_one_shot_delay.update(delay0.sum().item(), n=output_wo_retrans.size(0))
                test_one_shot_CLF_correcet.update(CLF_correct_set0.sum().item(), n=output_wo_retrans.size(0))

                # evaluate the classification and delay performance of always-retransmission
                test_always_retrans_delay.update(delay1.sum().item(), n=output_wo_retrans.size(0))
                test_always_retrans_CLF_correcet.update(CLF_correct_set1.sum().item(), n=output_wo_retrans.size(0))

                # evaluate the classification and delay performance of conventional ARQ
                crc_based_decision = arq_crc_decision(x_transmitted_binary, x_recovered_binary0, configs=self.configs)
                test_crc_based_CLF_correct_set = crc_based_decision * CLF_correct_set1 + (
                        1 - crc_based_decision) * CLF_correct_set0
                crc_based_delay = crc_based_decision * delay1 + (1 - crc_based_decision) * delay0
                test_crc_based_CLF_correct_num.update(test_crc_based_CLF_correct_set.sum().item(),
                                                      n=output_wo_retrans.size(0))
                test_crc_based_delay.update(crc_based_delay.sum().item(), n=output_wo_retrans.size(0))

        self.logger.log('Test CE loss: {}.'.format(test_loss.avg))
        self.logger.log('ARQ output-label matched ratio: {}'.format(test_ARQ_correct_num.avg))

        self.logger.log('ARQ-based classification accuracy: {}'.format(test_CLF_correct_num.avg))
        self.logger.log('ARQ-based communication delay: {}'.format(test_ARQ_delay.avg))

        self.logger.log('strans-based communication delay: {}'.format(test_one_shot_delay.avg))
        self.logger.log('strans-based classification accuracy: {}'.format(test_one_shot_CLF_correcet.avg))
        self.logger.log('always-retrans-based communication delay: {}'.format(test_always_retrans_delay.avg))
        self.logger.log('always-retrans-based classification accuracy: {}'.format(test_always_retrans_CLF_correcet.avg))
        self.logger.log('CRC-based communication delay: {}'.format(test_crc_based_delay.avg))
        self.logger.log('CRC-based classification accuracy: {}'.format(test_crc_based_CLF_correct_num.avg))

        result_path = os.path.join(self.configs.path, 'results/simulation_result/')
        os.makedirs(result_path, exist_ok=True)
        result = {'arq_acc': test_CLF_correct_num.avg,
                  'arq_delay': test_ARQ_delay.avg,
                  'strans_acc': test_one_shot_CLF_correcet.avg,
                  'strans_delay': test_one_shot_delay.avg,
                  'aretrans_acc': test_always_retrans_CLF_correcet.avg,
                  'aretrans_delay': test_always_retrans_delay.avg,
                  'crc_acc': test_crc_based_CLF_correct_num.avg,
                  'crc_delay': test_crc_based_delay.avg}
        result_save(data=result, path=result_path, configs=self.configs)

    def ARQ_label_producer(self, x_encoded, x_dequantized0, score0, CLF_label):
        retrans_score1_sum = 0
        for retran_id in range(self.configs.number_of_retrans_each_sample):
            x_received1, snr = self.data_communication.transmit(x=x_encoded, is_retransmission=True)
            x_decoded1 = self.data_communication.decoding_inference(x_received1)
            x_dequantized1 = self.data_communication.DAC(x_decoded1)

            x_dequantized0and1 = torch.cat((x_dequantized0, x_dequantized1), dim=1)
            output_w_retrans = self.CLF_model.classifier1(x_dequantized0and1)

            score1, _, _, _ = self.evaluator.arq_score(is_retransmission=True,
                                                       image_label=CLF_label,
                                                       predict=output_w_retrans)

            retrans_score1_sum = retrans_score1_sum + score1.data

            # AQR_decision_label = torch.gt(score0, score1).clone().detach().float()
            # AQR_decision_label_sum = AQR_decision_label_sum + AQR_decision_label
        score1_avg = retrans_score1_sum / self.configs.number_of_retrans_each_sample
        AQR_decision_label = torch.gt(score0, score1_avg).clone().detach().float()
        return AQR_decision_label


class ARQDataGenerator:
    def __init__(self, ARQ_model, CLF_model, configs):
        self.configs = configs
        self.number_of_snr_each_sample = configs.number_of_snr_each_sample
        self.log_path = os.path.join(configs.path,
                                     'log/{}/{}/snr{}_{}fe_{}bits_weight{}/'.format(
                                         configs.dataset,
                                         configs.task,
                                         configs.SNR_mean_in_dB,
                                         configs.CLF_intput_size_mlp,
                                         configs.quantization_level_in_bits,
                                         self.configs.delay_weight))

        # self.delay_weight_str = str(configs.delay_weight).replace('.', '_')
        self.ARQ_checkpoint_path = os.path.join(configs.path,
                                                'results/checkpoint/ARQ/snr{}_{}fe_{}bits_weight{}/'.format(
                                                    configs.SNR_mean_in_dB,
                                                    configs.CLF_intput_size_mlp,
                                                    configs.quantization_level_in_bits,
                                                    self.configs.delay_weight))

        self.CLF_checkpoint_path = os.path.join(configs.path,
                                                'results/checkpoint/CLF/snr{}_{}fe_{}bits/'.format(
                                                    configs.SNR_mean_in_dB,
                                                    configs.CLF_intput_size_mlp,
                                                    configs.quantization_level_in_bits))

        os.makedirs(self.log_path, exist_ok=True)
        os.makedirs(self.ARQ_checkpoint_path, exist_ok=True)
        os.makedirs(self.CLF_checkpoint_path, exist_ok=True)

        self.logger = Logger(self.log_path + 'log_{}_{}_{}.txt'.format(year, month, day), configs)
        args_data = ' '.join([f'{key}: {value},/n' for key, value in vars(configs).items()])
        self.logger.log(args_data)
        self.logger.log('ARQ model training...')

        self.device = configs.device
        self.CLF_model = CLF_model.to(self.device)
        self.ARQ_model = ARQ_model.to(self.device)

        _, _, _CLF_model_name = model_loder(model=self.CLF_model, task='CLF',
                                            path=self.CLF_checkpoint_path, configs=configs)

        self.CLF_model.requires_grad = False
        self.logger.log('Loading an existing CLF model {} from {}'.format(_CLF_model_name, self.CLF_checkpoint_path))

        self.train_loader, self.val_loader = get_dataloader(configs=configs)

        self.criterion = Criterion(criterion=configs.criterion_ARQ)
        self.optimizer = Optimizer(args=configs, model=self.ARQ_model)
        self.scheduler = Scheduler(args=configs, optimizer=self.optimizer)

        if configs.resume_checkpoint:
            self.loaded_epoch, self.min_loss, ARQ_model_name = model_loder(model=self.ARQ_model,
                                                                           task='ARQ',
                                                                           optimizer=self.optimizer,
                                                                           scheduler=self.scheduler,
                                                                           path=self.ARQ_checkpoint_path,
                                                                           configs=configs,
                                                                           load_schedule=True)
            self.logger.log('Resuming from an existing ARQ checkpoint {} from {}.'.format(ARQ_model_name,
                                                                                          self.ARQ_checkpoint_path))
        else:
            self.loaded_epoch = 0
            self.min_loss = 10000

        self.evaluator = EvaluationMetrics(configs=configs)
        self.data_communication = WirelessComm(**vars(configs))

        self.generate_dataset()

    def generate_dataset(self):
        self.logger.log('Generating ARQ dataset...')
        self.dataset_snr_sampling(input_dataset=self.train_loader,
                                  output_filename='reg_dataset_for_train_ARQ')
        self.dataset_snr_sampling(input_dataset=self.val_loader,
                                  output_filename='reg_dataset_for_valid_ARQ')

    def dataset_snr_sampling(self, input_dataset, output_filename):
        dataset_for_ARQ = []
        self.CLF_model.eval()
        try:
            with tqdm(input_dataset) as data_bar:
                for image, label in data_bar:
                    image = image.to(self.device)
                    label = label.to(self.device)

                    repeat_shape = (self.number_of_snr_each_sample,) + (1,) * (len(image.shape) - 1)
                    image_repeat = image.repeat(repeat_shape)
                    label_repeat = label.repeat(self.number_of_snr_each_sample)

                    x = image_repeat.flatten(start_dim=1)
                    x_feature = self.CLF_model.feature_extractor(x)
                    x_feature = self.CLF_model.activation(x_feature)

                    x_quantized = self.data_communication.ADC(x_feature)
                    x_encoded = self.data_communication.encoding_inference(x_quantized)

                    x_received0, snr = self.data_communication.transmit(x=x_encoded, is_retransmission=False)
                    x_decoded0 = self.data_communication.decoding_inference(x_received0)
                    x_dequantized0 = self.data_communication.DAC(x_decoded0)
                    output_wo_retrans = self.CLF_model.classifier0(x_dequantized0)

                    score0, _, _, _ = self.evaluator.arq_score(is_retransmission=False,
                                                               image_label=label_repeat,
                                                               predict=output_wo_retrans)

                    retrans_score_sum = 0
                    for retran_id in range(self.configs.number_of_retrans_each_sample):
                        x_received1, _ = self.data_communication.transmit(x=x_encoded, is_retransmission=True)
                        x_decoded1 = self.data_communication.decoding_inference(x_received1)
                        x_dequantized1 = self.data_communication.DAC(x_decoded1)

                        x_dequantized0and1 = torch.cat((x_dequantized0, x_dequantized1), dim=1)
                        output_w_retrans = self.CLF_model.classifier1(x_dequantized0and1)

                        score1, _, _, _ = self.evaluator.arq_score(is_retransmission=True,
                                                                   image_label=label_repeat,
                                                                   predict=output_w_retrans)

                        # score1.data很重要，否则这段for循环会占用大量的GPU内存空间
                        retrans_score_sum = retrans_score_sum + score1.data

                    score1_avg = retrans_score_sum / self.configs.number_of_retrans_each_sample

                    # # 在代码中的适当位置调用这两个函数，以检查GPU内存的使用情况
                    # allocated_memory = torch.cuda.memory_allocated(device=self.configs.device)
                    # cached_memory = torch.cuda.memory_reserved(device=self.configs.device)
                    #
                    # # 打印已分配和缓存的GPU内存量
                    # print(f"Allocated memory: {allocated_memory}")
                    # print(f"Cached memory: {cached_memory}")

                    AQR_decision_label = torch.gt(score0, score1_avg).clone().detach().int()

                    snr = snr.data.to('cpu')
                    output_wo_retrans = output_wo_retrans.data.to('cpu')
                    AQR_decision_label = AQR_decision_label.data.to('cpu')
                    x_latent_data = (snr, output_wo_retrans, AQR_decision_label)
                    dataset_for_ARQ.append(x_latent_data)
        except KeyboardInterrupt:
            data_bar.close()
            raise
        data_bar.close()

        dataset_path = os.path.join(self.configs.path, 'data/{}/ARQ_dataset/snr{}_{}fe_{}bits_weight{}/'.format(
            self.configs.dataset,
            self.configs.SNR_mean_in_dB,
            self.configs.CLF_intput_size_mlp,
            self.configs.quantization_level_in_bits,
            self.configs.delay_weight))
        os.makedirs(dataset_path, exist_ok=True)
        finetune_dataset_path = os.path.join(dataset_path, '{}.pt'.format(output_filename))
        torch.save(dataset_for_ARQ, finetune_dataset_path, pickle_protocol=4)
        self.logger.log('Success! The ARQ dataset is saved at {}'.format(finetune_dataset_path))
