
def result_save(data, path, configs):
    import json
    # 将数据保存到本地文件
    with open(path + '/result_snr{}_bits{}_weight{}.json'.format(configs.SNR_mean_in_dB,
                                                                 configs.quantization_level_in_bits,
                                                                 configs.delay_weight), 'w') as f:
        json.dump(data, f)


def extract_element(x, element_name):
    elements = x.split('_')
    extracted_elements = [element for element in elements if element_name in element]
    extracted_element = extracted_elements[0]
    if '.json' in extracted_element:
        extracted_element = extracted_element.replace('.json', '')
    return extracted_element.split(element_name)[-1]


def result_load(path, keyword1=None, keyword2=None, sort_key='snr'):
    import json
    import os
    # 定义数据目录
    data_dir = path
    # 获取数据目录下所有的 .json 文件
    data_files = [f for f in os.listdir(data_dir) if f.endswith('.json')]

    der_data_files = [f for f in data_files if (keyword1 is None or keyword1 in f)
                      and (keyword2 is None or keyword2 in f)]

    der_data_files = sorted(der_data_files, key=lambda x: int(extract_element(x, sort_key)))
    # 遍历每个数据文件
    all_data = []
    print('loading file...')
    for file_name in der_data_files:
        print(file_name)
        file_path = os.path.join(data_dir, file_name)

        # 读取并解析 JSON 文件
        with open(file_path, 'r') as file:
            data = json.load(file)

        # 提取所有的键值对
        all_data.append(data)

    return all_data


def result_plot(data_plot, key_names: list, line_styles: list, legend_names: list, x_ticks: list, x_title: str,
                y_title: str):
    valid_keys = ['arq_acc', 'arq_delay', 'strans_acc', 'strans_delay',
                  'aretrans_acc', 'aretrans_delay', 'crc_acc', 'crc_delay']
    for key in key_names:
        assert key in valid_keys, f"{key} is not a valid key"
        print(f"{key} is a valid key")

    import matplotlib.pyplot as plt

    for key, legend_name, line_style in zip(key_names, legend_names, line_styles):
        values = [data[key] for data in data_plot if key in data]
        plt.plot(range(len(values)), values, line_style, label=legend_name)
    # 绘制线图
    plt.xlabel(x_title)
    plt.ylabel(y_title)
    plt.legend()
    plt.xticks(range(len(x_ticks)), x_ticks)
    plt.grid()
    plt.show()


def result_plot_dual(save_name: str,
                     save_path: str,
                     data_plot: list,
                     key_names1: list,
                     key_names2: list,
                     line_styles: list,
                     legend_names: list,
                     x_ticks: list,
                     y_ticks1: list,
                     y_ticks2: list,
                     y_ticklabels1: list,
                     y_ticklabels2: list,
                     ):
    valid_keys = ['arq_acc', 'arq_delay', 'strans_acc', 'strans_delay',
                  'aretrans_acc', 'aretrans_delay', 'crc_acc', 'crc_delay']
    for key in key_names1 + key_names2:
        assert key in valid_keys, f"{key} is not a valid key"

    # 创建画布和子图
    import matplotlib.pyplot as plt
    # import matplotlib.patches as patches
    from mpl_toolkits.axes_grid1.inset_locator import mark_inset

    plt.rcParams["font.family"] = "Times New Roman"
    from matplotlib import rc
    rc('font', **{'family': 'Times New Roman', 'size': 12})
    rc('text', usetex=True)

    fig, (ax1, ax2) = plt.subplots(2, 1, sharex='all')
    
    # 设置放大区域的范围
    zoom_region = [0.1, 0.7, 0.2, 0.2]

    # 创建放大区域子图对象
    axins = ax1.inset_axes(zoom_region)
    
    key_value_dict={}

    for key, legend_name, line_style in zip(key_names1, legend_names, line_styles):
        values = [data[key] for data in data_plot if key in data]
        print(key, values)
        key_value_dict[key] = values
        
        ax1.plot(range(len(values)), values, line_style, label=legend_name)
        
        #zoom in
        # 在放大区域子图中绘制放大的部分
        # x_zoom = [2.5, 3, 3.5]
        # y_zoom = [4.5, 5, 5.5]
        # axins.plot([4,5], values[4:6], line_style)
        # line_styles=['-b^', '-gx', '-ko', '-r*']
    y_arq_acc = key_value_dict['arq_acc']
    y_strans_acc = key_value_dict['strans_acc'] 
    y_aretrans_acc = key_value_dict['aretrans_acc'] 
    y_crc_acc = key_value_dict['crc_acc'] 
    axins.plot(range(len(values)), y_arq_acc, 
               color='b',
               marker='^',
               linestyle='-')
    axins.plot(range(len(values)), y_strans_acc, 
               color='g',
               marker='x',
               linestyle='-')
    axins.plot(range(len(values)), y_aretrans_acc, 
               color='k',
               marker='o',
               linestyle='-')
    axins.plot(range(len(values)), y_crc_acc, 
               color='r',
               marker='*',
               linestyle='-')

    # 设置放大区域子图的样式
    # 设置放大区间
    zone_left = 3
    zone_right = 4

    # 坐标轴的扩展比例（根据实际数据调整）
    x_ratio = 0.1 # x轴显示范围的扩展比例
    y_ratio = 1 # y轴显示范围的扩展比例

    # X轴的显示范围
    x = range(len(values))
    # xlim0 = x[zone_left]-(x[zone_right]-x[zone_left])*x_ratio
    # xlim1 = x[zone_right]+(x[zone_right]-x[zone_left])*x_ratio
    xlim0 = 3.9
    xlim1 = 4.1
    # Y轴的显示范围
    import numpy as np
    y = np.hstack((y_arq_acc[zone_left:zone_right], 
                   y_strans_acc[zone_left:zone_right], 
                   y_aretrans_acc[zone_left:zone_right],
                   y_crc_acc[zone_left:zone_right]))
    # ylim0 = np.min(y)-(np.max(y)-np.min(y))*y_ratio
    # ylim1 = np.max(y)+(np.max(y)-np.min(y))*y_ratio
    ylim0 = 0.90
    ylim1 = 0.96
    # 调整子坐标系的显示范围
    axins.set_xlim(xlim0, xlim1)
    axins.set_ylim(ylim0, ylim1)
    
    # from matplotlib.lines import Line2D
    # dashed_line = Line2D([], [], linestyle='dashed', color='black')
    # dashed_line_rgba = dashed_line.get_color()
    
    mark_inset(ax1, axins, loc1=4, loc2=1, fc="none", ec='k', ls='--', lw=1)
    
    # xmin_zoom, xmax_zoom, ymin_zoom, ymax_zoom = 3.8, 5, 0.88, 0.97
    # axins.set_xlim(xmin_zoom, xmax_zoom)
    # axins.set_ylim(ymin_zoom, ymax_zoom)
    axins.set_yticks([0.90,0.96])
    axins.set_xticks([4])
    axins.set_xticklabels([6])
    axins.set_yticklabels([90,96])
    # axins.spines['top'].set_visible(False)
    # axins.spines['right'].set_visible(False)
    # ax1.indicate_inset_zoom(axins)
        
        

    for key, line_style in zip(key_names2, line_styles):
        values = [data[key] for data in data_plot if key in data]
        print(key, values)
        ax2.plot(range(len(values)), values, line_style)


    # 绘制线图
    x_title=r'Average SNR $\bar{\gamma}$ (dB)'
    y_title1='Accuracy (\%)'
    y_title2='Delay (ms)'
    
    ax1.set_ylabel(y_title1)
    ax1.set_yticks(y_ticks1)
    ax1.set_yticklabels(y_ticklabels1)
    ax1.legend()
    ax1.grid(True)

    ax2.set_ylabel(y_title2)
    ax2.set_yticks(y_ticks2)
    ax2.set_yticklabels(y_ticklabels2)
    ax2.grid(True)
    
    ax2.set_xlabel(x_title)
    ax2.set_xticks(range(len(x_ticks)))
    ax2.set_xticklabels(x_ticks)
    
    
    ax1.annotate('(a)', xy=(-0.105, 0.98), xycoords='axes fraction', fontsize=12, fontweight='bold')
    ax2.annotate('(b)', xy=(-0.105, 0.985), xycoords='axes fraction', fontsize=12, fontweight='bold')

    plt.subplots_adjust(hspace=0.3)
    plt.tight_layout()
    # plt.savefig(save_path+'{}.eps'.format(save_name), format='eps')
    plt.savefig(save_path + '{}.pdf'.format(save_name), format='pdf')

    plt.show()


def result_plot_retrans_ratio(save_name, save_path, data_plot):
    import matplotlib.pyplot as plt
    plt.rcParams["font.family"] = "Times New Roman"
    from matplotlib import rc
    rc('font', **{'family': 'Times New Roman', 'size': 12})
    rc('text', usetex=True)
    
    key_names = ['arq_delay', 'crc_delay']
    start_bars=[0, 0.25]
    label_names = ['TARQ', 'HARQ']
    import numpy as np
    for key, start_bar, label in zip(key_names, start_bars, label_names):
        values = [data[key] for data in data_plot if key in data]
        trans_ratio = (np.array(values)-0.01)/0.01*100
        print(key, trans_ratio)
        plt.bar(np.arange(0, len(values))+start_bar, trans_ratio, width=0.25, label=label)
    
    x_title=r'Average SNR $\bar{\gamma}$ (dB)'
    y_title='Re-transmission ratio (\%)'
    plt.xlabel(x_title)
    plt.ylabel(y_title)
    x_ticks=[-6, -3, 0, 3, 6, 9]
    import numpy as np
    plt.xticks(np.arange(0,len(x_ticks))+0.125, x_ticks)
    plt.grid(True)
    plt.legend()
    plt.savefig(save_path + '{}.pdf'.format(save_name), format='pdf')

    plt.show()


def result_plot_delay_vs_acc(save_name, save_path, data_plot, line_styles: list,
                             x_ticks: list, x_title: str, y_title: str):

    import matplotlib.pyplot as plt
    from matplotlib.patches import FancyArrow
    plt.rcParams["font.family"] = "Times New Roman"
    from matplotlib import rc
    rc('font', **{'family': 'Times New Roman', 'size': 13})
    rc('text', usetex=True)

    values_x = [20-1000*data['arq_delay'] for data in data_plot if 'arq_delay' in data]
    values_y = [100*data['arq_acc'] for data in data_plot if 'arq_acc' in data]

    # values_x.insert(0, 20-1000*data_plot[0]['aretrans_delay'])
    # values_x.append(20-1000*data_plot[0]['strans_delay'])
    # values_y.insert(0, 100*data_plot[0]['aretrans_acc'])
    # values_y.append(100*data_plot[0]['strans_acc'])

    plt.plot(values_x, values_y, line_styles[0])
    font = 13
    plt.text(4.2, 91.6, r'$\omega=1$', fontsize=font)
    plt.text(6.2, 91.5, r'2', fontsize=font)
    plt.text(6.8, 91.45, r'4', fontsize=font)
    plt.text(7.5, 91.1, r'8', fontsize=font)
    plt.text(7.9, 90.8, r'16', fontsize=font)
    plt.text(8.2, 90.15, r'32', fontsize=font)

    # plt.text(1, 91, 'Always \n re-transmission', fontsize=font, ha='center')
    # plt.arrow(0.1, 0.915, -0.1, 0.003, width=0.001, color='black')
    # arrow = FancyArrow(0.1, 0.915, -0.1, 0.003, width=0.02, color='black', head_width=0.01,
    #                    head_length=0.01, length_includes_head=False)
    # plt.gca().add_patch(arrow)
    # plt.text(7.5, 87, 'Single \n transmission', fontsize=font, ha='center')

    # 绘制线图
    plt.xlabel(x_title)
    plt.ylabel(y_title)
    # plt.xticks(range(len(x_ticks)), x_ticks)
    plt.grid()
    plt.tight_layout()
    # plt.savefig(save_path + '{}.eps'.format(save_name), format='eps')
    plt.savefig(save_path + '{}.pdf'.format(save_name), format='pdf')
    plt.show()
    
    
def result_plot_round(save_path, save_name):
    import torch
    import numpy as np
    import matplotlib.pyplot as plt
    import matplotlib.gridspec as gridspec
    from util.utils import sin_round
    
    plt.rcParams["font.family"] = "Times New Roman"
    from matplotlib import rc
    rc('font', **{'family': 'Times New Roman', 'size': 12})
    rc('text', usetex=True)

    start = -2
    end = 2
    step = 0.01
    x = torch.arange(start, end + step, step)
    x_sin_rounded1 = sin_round(x, max_iterations=1)
    x_sin_rounded2 = sin_round(x, max_iterations=2)
    x_sin_rounded3 = sin_round(x, max_iterations=3)
    x_rounded = torch.round(x)

    # 创建包含一个大的子图和两个小的子图的图形
    fig = plt.figure()
    gs = gridspec.GridSpec(2, 2, width_ratios=[1, 1], height_ratios=[1, 1])

    ax1 = plt.subplot(gs[:, 0])
    ax1.plot(x, x_rounded, '-r', label=r'torch.round($x$)')
    ax1.plot(x, x_sin_rounded1, '-b', label=r'$R_{\rm {sin}}(x,n=1)$')
    ax1.plot(x, x_sin_rounded2, '-k', label=r'$R_{\rm {sin}}(x,n=2)$')
    ax1.plot(x, x_sin_rounded3, '-g', label=r'$R_{\rm {sin}}(x,n=3)$')
    ax1.grid()
    ax1.legend(fontsize=11)
    ax1.set_xticks([-2,-1,0,1,2])
    ax1.set_xlabel(r'$x$')
    ax1.set_ylabel('Function output')
    ax1.annotate('(a)', xy=(-0.2, 0.98), xycoords='axes fraction', fontsize=12, fontweight='bold')

    start = 0
    end = 29
    step = 1
    time = torch.arange(start, end + step, step)
    loss_rounded = [4.6223406640625,4.6056724951171875,4.604799612630209,4.604245942382812,4.604021180826823,4.603767156575521,4.603561424967448,4.603551952311198,4.603355945638021,4.60337154296875,4.603163570149739,4.603132934570312,4.603071196289062,4.603007266438802,4.60304021077474,4.602896668294271,4.602860563151042,4.602852635904948,4.60282267578125,4.602839905598958,4.602673863932291,4.602663634440104,4.602657456054687,4.60268734375,4.602653117675781,4.602562620442709,4.602539335123698,4.602549376627604,4.602536053873698,4.60255081217448,]
    acc_w_rounded = [0.10565083333333333,0.1060425,0.10599333333333333,0.106035,0.10598333333333333,0.10597,0.105995,0.1060175,0.10599083333333334,0.10597416666666666,0.1059975,0.10598833333333334,0.10601166666666667,0.1060025,0.10600416666666666,0.10599916666666667,0.10602833333333334,0.10600166666666666,0.10600583333333333,0.10598416666666667,0.10599083333333334,0.10599833333333333,0.105995,0.10598333333333333,0.10599916666666667,0.10599916666666667,0.10600166666666666,0.106,0.10600166666666666,0.10599833333333333,]
    acc_w_rounded = np.array(acc_w_rounded)*100
    
    loss_sin_round1 = [1.7985637666829426,1.392251289876302,1.3045318823242187,1.2717814034016928,1.234134198811849,1.2110772285970053,1.1934167468261718,1.1869488067626952,1.1654452840169272,1.1678016955566406,1.1528839876302084,1.1504618141682943,1.1349433866373697,1.1359431119791668,1.1214537056477865,1.115389638264974,1.1125496984863281,1.1019264986165365,1.0926467004394531,1.0884641149902343,1.083540830078125,1.0759044954427084,1.077824034830729,1.0684148087565104,1.0690789721679688,1.0623260426839192,1.0629068786621094,1.0600096598307291,1.052786267903646,1.052976508992513,]
    acc_w_sin_round1 = [0.8765525,0.8939691666666667,0.9006641666666667,0.9062366666666667,0.90489,0.9090666666666667,0.907605,0.9098525,0.9065158333333333,0.9069475,0.9094725,0.9092858333333333,0.9090925,0.9118075,0.9113591666666667,0.9124183333333333,0.9128766666666667,0.9107325,0.9140541666666666,0.9142516666666667,0.9105866666666667,0.91432,0.9157283333333334,0.9166191666666667,0.915415,0.9144483333333333,0.915785,0.9167166666666666,0.9162266666666666,0.917815,]
    acc_w_sin_round1 = np.array(acc_w_sin_round1)*100
    
    loss_sin_round2 = [1.8433299446614584,1.3931653100585937,1.3011536157226562,1.2604007397460937,1.2248621921793619,1.1972709651692708,1.1793079976399738,1.167812608235677,1.1482722399902343,1.1543382169596355,1.1328297371419271,1.1322232301839192,1.1150559684244792,1.1134010428873697,1.1032579252115886,1.099790654296875,1.0905832484944662,1.0817048465983072,1.0775511625162761,1.0696650602213542,1.0573950431315104,1.0507556001790364,1.048581758219401,1.0461171130371094,1.0479834342447916,1.0369479370117187,1.0380196313476562,1.0385339709472656,1.0275948811848958,1.0299029982503256,]
    acc_w_sin_round2 = [0.8729325,0.8879066666666666,0.8959233333333333,0.9017825,0.906665,0.906275,0.9089033333333333,0.908595,0.90612,0.90219,0.9087941666666667,0.9080116666666667,0.9092,0.9087258333333333,0.9090558333333333,0.9088608333333333,0.9133116666666666,0.9129441666666667,0.9119225,0.9111833333333333,0.9134058333333334,0.9149508333333334,0.9148341666666666,0.9125308333333333,0.9145083333333334,0.913995,0.9142433333333333,0.9157116666666667,0.9140791666666667,0.9163141666666667,]
    acc_w_sin_round2 = np.array(acc_w_sin_round2)*100
    
    loss_sin_round3 = [1.9364726399739582,1.4853214404296875,1.3754158439127604,1.3356293017578125,1.3031493025716145,1.2640377421061197,1.250026024169922,1.2368671077473958,1.2226736572265624,1.2132958536783853,1.195590557047526,1.1930652537027995,1.177154205118815,1.1667156260172526,1.1681045052083334,1.1584035333251954,1.1540709098307291,1.1394466280110678,1.1424628930664062,1.129921900024414,1.1175632041422525,1.1121729223632812,1.1095886372884114,1.1116331958007812,1.1051875547281902,1.0934137235514323,1.0932487290445962,1.0931497611490886,1.0860488232421874,1.0965657470703125,]
    acc_w_sin_round3 = [0.8594983333333334,0.8830966666666666,0.8945091666666667,0.8950708333333334,0.90385,0.9024025,0.9051583333333333,0.9044616666666667,0.9039083333333333,0.9032933333333333,0.9079741666666666,0.9078883333333333,0.9088925,0.9090475,0.9103958333333333,0.9102966666666666,0.9095158333333333,0.9103025,0.9108033333333333,0.9112066666666667,0.9119916666666666,0.9133741666666667,0.9138558333333333,0.9110658333333334,0.9132841666666667,0.9140783333333333,0.9136566666666667,0.9151375,0.9119083333333333,0.9146,]
    acc_w_sin_round3 = np.array(acc_w_sin_round3)*100
    
    ax2 = plt.subplot(gs[0, 1])
    ax2.plot(time, loss_rounded[start:end+1], '-r', label='torch_round')
    ax2.plot(time, loss_sin_round1[start:end+1], '-b', label=r'sin_round ($n=1$)')
    ax2.plot(time, loss_sin_round2[start:end+1], '-k', label=r'sin_round ($n=2$)')
    ax2.plot(time, loss_sin_round3[start:end+1], '-g', label=r'sin_round ($n=3$)')
    ax2.grid()
    # ax2.set_yticks([4.60,4.61,4.62])
    ax2.set_ylabel('Training loss')
    # ax2.set_xlabel('Training epoches')
    ax2.annotate('(b)', xy=(-0.2, 0.95), xycoords='axes fraction', fontsize=12, fontweight='bold')
    
    ax3 = plt.subplot(gs[1, 1], sharex=ax2)
    ax3.plot(time, acc_w_rounded[start:end+1], '-r', label='torch_round')
    ax3.plot(time, acc_w_sin_round1[start:end+1], '-b', label=r'sin_round ($n=1$)')
    ax3.plot(time, acc_w_sin_round2[start:end+1], '-k', label=r'sin_round ($n=2$)')
    ax3.plot(time, acc_w_sin_round3[start:end+1], '-g', label=r'sin_round ($n=3$)')
    ax3.grid()
    ax3.set_yticks([10, 30, 50, 70, 90])
    ax3.set_ylabel('Accuracy (\%)')
    ax3.set_xlabel('Training epoches')
    ax3.annotate('(c)', xy=(-0.2, 0.95), xycoords='axes fraction', fontsize=12, fontweight='bold')

    # 调整子图之间的间距
    # plt.subplots_adjust(wspace=0.4, hspace=0.4)

    # 在整个大图的外部放置图例
    handles, labels = ax1.get_legend_handles_labels()
    # fig.legend(handles, labels, loc='lower center', bbox_to_anchor=(0.5, 0), ncol=2)
    # plt.figlegend(labels, loc = 'lower center', bbox_to_anchor=(0.5,-0.03), borderaxespad=0.1, ncol=4, labelspacing=0.,  prop={'size': 12})
    plt.tight_layout()
    fig.savefig(save_path + '{}.pdf'.format(save_name), format='pdf')
    plt.show()
    
    
    


# using the code below to extract data from txt files
# file_path = 'C:/Users/XIANLI/Desktop/3.txt'

# def extract_loss_values_from_file(file_path):
#     import re
#     loss_values = []
#     acc_w_retrans = []
#     acc_wo_retrans = []

#     with open(file_path, 'r') as file:
#         lines = file.readlines()

#         for line in lines:
#             if "training CE loss" in line:
#                 start_index = line.find("training CE loss") + len("training CE loss")
#                 end_index = line.find(",", start_index)
#                 loss_value = float(line[start_index:end_index])
#                 loss_values.append(loss_value)
            
#             if "val_acc_w" in line:
#                 # start_index = line.find("val_acc_w") + len("val_acc_w")
#                 # end_index = line.find(",", start_index)
#                 match = re.search(r"val_acc_w (\d+\.\d+)", line)
#                 acc_w = match.group(1)
#                 # acc_w = float(line[start_index:end_index])
#                 acc_w_retrans.append(acc_w)
                
#             if "val_acc_wo" in line:
#                 start_index = line.find("val_acc_wo") + len("val_acc_wo")
#                 end_index = line.find(",", start_index)               
#                 acc_wo = float(line[start_index:end_index])
#                 acc_wo_retrans.append(acc_wo)
                

#     return loss_values, acc_w_retrans, acc_wo_retrans


# def save_loss_values_to_file(loss_values, file_path):
#     with open(file_path, 'a') as file:
#         file.write('\n')
#         for loss_value in loss_values:
#             file.write(str(loss_value) + ',')
#         file.write('\n')

# value, acc_w_retrans, acc_wo_retrans = extract_loss_values_from_file(file_path)

# save_loss_values_to_file(value, file_path)

# save_loss_values_to_file(acc_w_retrans, file_path)