import torch


def Optimizer(args, model):
    if args.optimizer == 'Adam':
        optimizer = torch.optim.Adam(params=model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    elif args.optimizer == 'SGD':
        optimizer = torch.optim.SGD(params=model.parameters(), lr=args.lr, momentum=0.9, weight_decay=1e-4)
    elif args.optimizer == 'RAdam':
        optimizer = torch.optim.RAdam(
            params=model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    else:
        raise ValueError(f"Unknown Optimizer {args.optimizer}. It should be Adam, SGD, or RAdam")
    return optimizer


def Scheduler(args, optimizer):
    if args.scheduler == 'Reduce':
        scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
            optimizer, mode='min', factor=args.lr_factor, patience=args.patience)
    elif args.scheduler == 'Step':
        scheduler = torch.optim.lr_scheduler.StepLR(
            optimizer, step_size=5, gamma=0.9)
    else:
        raise ValueError(f"Unknown Optimization scheduler {args.scheduler}. It should be Reduce or Step")
    return scheduler


def Criterion(criterion, reduction='sum'):
    if criterion == 'MSE':
        func = torch.nn.MSELoss(reduction=reduction)
    elif criterion == 'BCE':
        # Caution: there is a sigmoid in BCEWithLogitsLoss
        # func = torch.nn.BCEWithLogitsLoss()
        func = torch.nn.BCELoss(reduction=reduction)
    elif criterion == 'CE':
        # Caution: there is a Logsoftmax in CrossEntropyLoss
        func = torch.nn.CrossEntropyLoss(reduction=reduction)
        # func = torch.nn.NLLLoss(reduction=reduction)
    else:
        raise ValueError(f"Unknown Criterion {criterion}.")
    return func
