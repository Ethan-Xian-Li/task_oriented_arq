from datetime import datetime


class Logger:
    def __init__(self, filename, configs):
        self.filename = filename
        self.log_level = configs.log_level
        with open(self.filename, 'a') as file:
            file.write('\n------------------start time: {}---------------------\n'.format(datetime.now()))

    def log(self, data, log_level="INFO"):
        log_levels = ["DEBUG", "INFO", "WARNING", "ERROR"]

        if log_level not in log_levels:
            raise ValueError("Invalid log level")

        if log_levels.index(log_level) >= log_levels.index(self.log_level):
            formatted_data = f'{data:<100}'  # 使用左对齐，总宽度为100个字符
            try:
                with open(self.filename, 'a') as file:
                    file.write(f'[{log_level}] {formatted_data}\n')
                print(f'[{log_level}] {formatted_data}\n')

            except Exception as error:
                print(f"Logging Error: {str(error)}")


if __name__ == '__main__':
    logger = Logger('log.txt')
    logger.log('这是一条日志信息')
    logger.log('另一条日志信息')
