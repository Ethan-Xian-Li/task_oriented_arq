import torchvision
import torch
import os
import torchvision.datasets as torch_datasets
import torch.nn.functional as F
from torch.utils.data import DataLoader, Subset
from torchvision.transforms import (Compose, ToTensor, Normalize,
                                    Resize, RandomResizedCrop, RandomHorizontalFlip,
                                    CenterCrop, ColorJitter, RandomRotation, RandomAffine)
from torchvision import transforms
from util.utils import cat_entropy

# Define a function to save images
def save_image(inpout_tensor, filename):
    # Assuming output is a PyTorch tensor, normalize it to [0, 255] range
    inpout_tensor = (inpout_tensor * 0.5 + 0.5) * 255

    # Make sure it's in the right data type for saving as an image
    inpout_tensor = inpout_tensor.type(torch.uint8)

    # Convert the PyTorch tensor to a PIL image
    image = transforms.ToPILImage()(inpout_tensor)
    # Save the PIL image
    image.save(filename)


class FinetuneDataset:
    def __init__(self, data):
        self.data = data

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        x_dequantized0, x_dequantized1, orig_img = self.data[idx]
        return {
            'x_dequantized0': x_dequantized0,
            'x_dequantized1': x_dequantized1,
            'orig_img': orig_img,
        }


class ARQDataset:
    def __init__(self, data, transform=None):
        self.data = data
        self.transform = transform

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        snr, output_wo_retrans, AQR_decision_label = self.data[idx]
        sample = {
            'snr': snr,
            'output_wo_retrans': output_wo_retrans,
            'AQR_decision_label': AQR_decision_label,
        }
        if self.transform:
            sample = self.transform(sample)
        return sample


def ARQ_data_process(x, snr):
    x_after_softmax = F.softmax(x, dim=1)
    data_entropy = cat_entropy(x_after_softmax)

    # SNR_mean = 10 ** (configs.SNR_mean_in_dB / 10)
    # SNR_std = SNR_mean
    # snr = (snr - SNR_mean) / SNR_std

    snr = snr / 10
    ARQ_input = torch.cat((data_entropy, snr), dim=1)

    return ARQ_input


class SelfDefinedNormalizeARQDataset:
    def __init__(self):
        self.output_wo_retrans_std = torch.tensor(
            [3.8574, 3.6581, 3.6752, 3.4649, 3.6250, 3.4752, 3.8220, 3.4364, 3.6674, 3.4307])
        self.output_wo_retrans_mean = torch.tensor([-0.3660, 0.1035, -0.1943, 0.2371, -0.1786, -0.1085, -0.2061, 0.0134,
                                                    -0.2786, 0.0383])
        self.snr_mean = torch.tensor(1.9936)
        self.snr_std = torch.tensor(1.9945)

    def __call__(self, sample):
        snr = (sample['snr'] - self.snr_mean) / self.snr_std
        output_wo_retrans = (sample['output_wo_retrans'] - self.output_wo_retrans_mean) / self.output_wo_retrans_std
        sample['snr'] = snr
        sample['output_wo_retrans'] = output_wo_retrans
        return sample


def get_dataloader(configs):
    dataset_path = os.path.join(configs.path, 'data/{}/'.format(configs.dataset))
    os.makedirs(dataset_path, exist_ok=True)
    if 'CLF' in configs.task:
        return load_CLF_dataset(dataset_path, configs)
    elif 'ARQ' in configs.task:
        return load_ARQ_dataset(dataset_path, configs)
    else:
        raise ValueError('please set configs.task as CLF or ARQ.')


def load_self_defined_dataset(dataset_path, configs):
    print('loading self-defined dataset from {}'.format(dataset_path))
    loaded_data = torch.load(dataset_path, map_location=configs.device)
    ARQtransform = SelfDefinedNormalizeARQDataset()
    if configs.task == 'CLF':
        # loaded_data 是一个包含 n 个 batch 的列表
        # 每个 batch 包含一个元组，其中每个元组包含三个 Tensor
        # 三个 Tensor 的维度为B*x*x*x, 对应B条 x_dequantized0， x_dequantized1，original_image 数据
        # 创建一个新的数据列表，用于保存扁平化后的数据
        flat_data = []
        # 将 loaded_data 中的元组按数据个数扁平化
        for batch in loaded_data:
            x_dequantized0, x_dequantized1, orig_img = batch
            data_length = x_dequantized0.size(0)  # 获取当前 batch 中数据的数量
            for i in range(data_length):
                flat_data.append((x_dequantized0[i], x_dequantized1[i], orig_img[i]))
        return FinetuneDataset(flat_data)
    elif configs.task == 'ARQ':
        flat_data = []
        # 将 loaded_data 中的元组按数据个数扁平化
        for batch in loaded_data:
            snr, output_wo_retrans, action_label = batch
            data_length = snr.size(0)  # 获取当前 batch 中数据的数量
            for i in range(data_length):
                flat_data.append((snr[i], output_wo_retrans[i], action_label[i]))
        return ARQDataset(flat_data, transform=None)
    else:
        raise ValueError('self-defined dataset loading failed.')


def load_ARQ_dataset(data_path, configs):
    batch_size = configs.batch_size
    if configs.action == 'train':
        dataset_parent_path = data_path
        dataset_train_path = os.path.join(dataset_parent_path,
                                          'ARQ_dataset/snr{}_{}fe_{}bits_weight{}/reg_dataset_for_train_ARQ.pt'.format(
                                              configs.SNR_mean_in_dB,
                                              configs.CLF_intput_size_mlp,
                                              configs.quantization_level_in_bits,
                                              configs.delay_weight))
        dataset_valid_path = os.path.join(dataset_parent_path,
                                          'ARQ_dataset/snr{}_{}fe_{}bits_weight{}/reg_dataset_for_valid_ARQ.pt'.format(
                                              configs.SNR_mean_in_dB,
                                              configs.CLF_intput_size_mlp,
                                              configs.quantization_level_in_bits,
                                              configs.delay_weight))
        if os.path.exists(dataset_train_path):
            train_dataset = load_self_defined_dataset(dataset_path=dataset_train_path, configs=configs)
            valid_dataset = load_self_defined_dataset(dataset_path=dataset_valid_path, configs=configs)
            # return DataLoader(train_dataset, batch_size=len(train_dataset), shuffle=True), \
            #        DataLoader(valid_dataset, batch_size=len(valid_dataset), shuffle=True)
            # # else:
            return DataLoader(train_dataset, batch_size=batch_size, shuffle=True), \
                   DataLoader(valid_dataset, batch_size=batch_size, shuffle=True)
        else:
            raise ValueError('There is no ARQ dataset at {}. Please set action as datagen.'
                             'Using model.generate_dataset() to generate data.'.format(dataset_train_path))
    else:
        return load_torchvision_dataset(data_path, configs)


def load_CLF_dataset(data_path, configs):
    batch_size = configs.batch_size
    if 'finetune' in configs.action:
        dataset_parent_path = data_path
        dataset_train_path = os.path.join(dataset_parent_path, 'finetune_dataset/dataset_for_train_CLF_classifier.pt')
        dataset_valid_path = os.path.join(dataset_parent_path, 'finetune_dataset/dataset_for_valid_CLF_classifier.pt')
        if os.path.exists(dataset_train_path):
            train_dataset = load_self_defined_dataset(dataset_path=dataset_train_path, configs=configs)
            valid_dataset = load_self_defined_dataset(dataset_path=dataset_valid_path, configs=configs)

            return DataLoader(train_dataset, batch_size=batch_size, shuffle=True), \
                   DataLoader(valid_dataset, batch_size=batch_size, shuffle=True)
        else:
            print('Generating fine-tuning dataset...')
            return load_torchvision_dataset(data_path, configs)
    else:
        return load_torchvision_dataset(data_path, configs)


def load_torchvision_dataset(data_path, configs):
    dataset_dict = {
        'MNIST': torch_datasets.MNIST,
        'CIFAR10': torch_datasets.CIFAR10,
    }

    if configs.dataset in dataset_dict:
        print('loading dataset from {}'.format(data_path))
    else:
        raise ValueError('please select a dataset in {}'.format(dataset_dict))

    batch_size = configs.batch_size
    if 'train' in configs.action or 'datagen' in configs.action:
        transform = get_train_augmentation(configs)
        train_and_valid_dataset = dataset_dict[configs.dataset](root=data_path, train=True,
                                                                transform=transform, download=True)
        set_len = len(train_and_valid_dataset)
        train_set_size, valid_set_size = int(0.8 * set_len), int(0.2 * set_len)
        train_set, valid_set = Subset(train_and_valid_dataset, list(range(train_set_size))), Subset(
            train_and_valid_dataset, list(range(train_set_size, set_len)))
        return DataLoader(train_set, batch_size=batch_size, shuffle=True), DataLoader(valid_set, batch_size=batch_size,
                                                                                      shuffle=True)
    else:
        transform = get_test_augmentation(configs)
        dataset = dataset_dict[configs.dataset](root=data_path, train=False, transform=transform, download=True)

        return DataLoader(dataset, batch_size=batch_size, shuffle=True), None


def get_train_augmentation(configs):
    type_of_dataset = configs.dataset
    if type_of_dataset == 'CIFAR10':
        transform = Compose([Resize(40),
                             RandomResizedCrop(32, scale=(0.64, 1.0), ratio=(1.0, 1.0)),
                             RandomHorizontalFlip(),
                             ToTensor(),
                             Normalize((0.4914, 0.4822, 0.4465),
                                       (0.2023, 0.1994, 0.2010))])
    elif type_of_dataset == 'MNIST':
        transform = Compose([
            CenterCrop(26),
            Resize((28, 28)),
            ColorJitter(brightness=0.05, contrast=0.05, saturation=0.05, hue=0.05),
            RandomRotation(10),
            RandomAffine(5),
            ToTensor(),
            Normalize((0.1307,), (0.3081,))
        ])
    else:
        raise ValueError('please select an appropriate dataset, e.g., CIFAR10')
    return transform


def get_test_augmentation(configs):
    type_of_dataset = configs.dataset
    if type_of_dataset == 'CIFAR10':
        transform = Compose([ToTensor(),
                             Normalize((0.4914, 0.4822, 0.4465),
                                       (0.2023, 0.1994, 0.2010))])
    elif type_of_dataset == 'MNIST':
        transform = Compose([
            ToTensor(),
            Normalize((0.1307,), (0.3081,))
        ])
    else:
        raise ValueError('please select an appropriate dataset, e.g., CIFAR10')
    return transform


def model_loder(model, task, path, configs, optimizer=None, scheduler=None, load_schedule=False):
    try:
        model_name = '{}_{}_checkpoint_{}_{}.pth'.format(
            configs.type_of_model,
            task,
            configs.dataset,
            configs.wirelesscom_channel_mode)
        checkpoint = torch.load(path + model_name, map_location=configs.device)
        model.load_state_dict(checkpoint['model_state_dict'])
        if load_schedule:
            optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
            scheduler.load_state_dict(checkpoint['scheduler_state_dict'])
        return checkpoint['epoch'], checkpoint['min_loss'], model_name
    except Exception as error:
        raise Exception(
            'This is no {}_{}_checkpoint_{}_{}.pth in path {}. Please train or use another checkpoint: {}'.format(
                configs.type_of_model, configs.task, configs.dataset, configs.wirelesscom_channel_mode, path,
                str(error)))


def model_saver(epoch, min_loss, model, optimizer, scheduler, path, configs):
    checkpoint = {
        'epoch': epoch + 1,
        'min_loss': min_loss,
        'model_state_dict': model.state_dict(),
        'optimizer_state_dict': optimizer.state_dict(),
        'scheduler_state_dict': scheduler.state_dict(),
    }
    try:
        torch.save(checkpoint, os.path.join(path, '{}_{}_checkpoint_{}_{}.pth'.format(
            configs.type_of_model, configs.task, configs.dataset, configs.wirelesscom_channel_mode)))
    except Exception as error:
        print('Checkpoint saving failed:{}'.format(str(error)))
