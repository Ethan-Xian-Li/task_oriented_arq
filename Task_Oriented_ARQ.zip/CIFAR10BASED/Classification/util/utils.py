import torch
import time


def Q_function(x):
    # 使用 PyTorch 的标准正态分布计算 CDF
    cdf_x = 0.5 * (1 + torch.erf(x / (2 ** 0.5)))
    return 1 - cdf_x


def binarystr_to_binarylist(x):
    # intput x: str
    # output y: list
    y = [float(i) for i in x]
    return y


def binarytensor_to_binarystr(tensor):
    # input: binary tensor
    # output: binary string
    # example:
    # input tensor([[1.0, 0.0, 1.0, 1.0, 0.0],[0.0, 1.0, 0.0, 0.0, 1.0]])
    # output ['10110','01001']
    binary_strings = []
    for row in tensor:
        rounded_row = torch.round(row).to(torch.int)
        binary_string = ''.join([str(element.item()) for element in rounded_row])
        binary_strings.append(binary_string)
    return binary_strings


def arq_crc_decision(received, target, configs, threshold=0.0):
    received = received.float()
    target = target.float()
    diff_ratio = torch.mean(torch.abs(received - target), dim=(1, 2))
    # if the difference between received and target is greater than threshold, then retransmit
    ARQ_decision = torch.where(diff_ratio > threshold,
                               torch.tensor(1).to(configs.device),
                               torch.tensor(0).to(configs.device))
    return ARQ_decision


def int_2_binary(x, bits: int):
    # input tensor x is in the shape of B, C, H, W
    # bits is the number of binary bits used to present the integer
    # make sure that x is of int type
    x = x.int()

    binary_repr_list = []
    for value in x.view(-1).tolist():
        # 构造一个格式化字符串，其中 '0' 代表在不足位数时用零填充，str(bits) 代表要生成的二进制位数， 'b' 表示二进制格式。
        binary_repr = format(value, '0' + str(bits) + 'b')
        binary_repr_list.append(binary_repr)

    # 将二进制字符串'0011'表示为二进制列表[0,0,1,1]，并将其转换成tensor
    binary_signal = torch.tensor([list(map(int, binary_repr)) for binary_repr in binary_repr_list], dtype=torch.int)

    # 计算新的张量的形状
    new_shape = x.shape + (bits,)

    # 恢复原始形状
    binary_signal = binary_signal.view(new_shape)
    return binary_signal


def ser_in_average(x, y):
    # x and y are tensors with size torch.size(batchsize, N)
    nonequal_elements = torch.ne(x, y)
    nonequal_counts = torch.sum(nonequal_elements, dim=1)
    ser_avr = torch.mean(nonequal_counts / x.shape[1])
    return ser_avr


def timing_decorator(func):
    def wrapper(*args, **kwargs):
        start_time = time.time()
        result = func(*args, **kwargs)
        end_time = time.time()
        execution_time = end_time - start_time
        print(f"{func.__name__} took {execution_time} seconds")
        return result

    return wrapper


def sin_round(x, max_iterations=3, current_iteration=1):
    pi = 3.141592653589793
    result = x - torch.sin(2 * pi * x) / (2 * pi)
    if current_iteration < max_iterations:
        return sin_round(result, max_iterations, current_iteration + 1)
    else:
        return result


def cat_entropy(x):
    import torch.distributions as dist

    # 创建一个概率分布
    cat = dist.Categorical(probs=x)

    # 计算信息熵
    entropy = cat.entropy()

    return entropy.unsqueeze(dim=1)


def plot_scatter(data, label):
    import matplotlib.pyplot as plt

    data = data.cpu().detach().numpy()
    label = label.cpu().detach().numpy()

    # 绘制散点图
    plt.scatter(data, label)
    plt.xlabel('Predict')
    plt.ylabel('Label')
    plt.title('Data and Label Relationship')
    plt.show()


class AvgMeter(object):
    def __init__(self, num=40):
        self.num = num
        self.reset()

    def reset(self):
        self.val = 0
        self.avg = 0
        self.sum = 0
        self.count = 0
        self.losses = []

    def update(self, val, n=1):
        self.val = val
        self.sum += val
        self.count += n
        self.avg = self.sum / self.count
        self.losses.append(val)
