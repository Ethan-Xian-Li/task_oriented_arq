from pytorch_msssim import ssim
from torchmetrics.image import PeakSignalNoiseRatio
import torch
from util.losses import Criterion


class EvaluationMetrics:
    def __init__(self, configs):
        self.configs = configs
        self.CLF_loss = Criterion(criterion=configs.criterion_CLF, reduction='none')

    def measure_all(self, image_in_tensor_1, image_in_tensor_2):
        ssim_val = self.ssim(image_in_tensor_1, image_in_tensor_2)
        psnr_val = self.psnr(image_in_tensor_1, image_in_tensor_2)
        return ssim_val, psnr_val

    def ssim(self, image_in_tensor_1, image_in_tensor_2, size_average=True):
        ssim_val = ssim(image_in_tensor_1, image_in_tensor_2, size_average=size_average)
        return ssim_val

    def psnr(self, image_in_tensor_1, image_in_tensor_2):
        psnr_metric = PeakSignalNoiseRatio().to(self.configs.device)
        psnr_val = psnr_metric(image_in_tensor_1, image_in_tensor_2)
        return psnr_val

    def delay(self, is_retransmission):
        if is_retransmission:
            unit_delay = 2 * self.configs.delay
        else:
            unit_delay = self.configs.delay
        return unit_delay

    def correct_set(self, label, predicted):
        prediction = torch.max(predicted.data, 1)[1].data
        corrects = (prediction == label).int()
        return corrects

    def loss_clf(self, output, label):
        return self.CLF_loss(output, label)

    # ARQ function is only used for evaluation, rather making an ARQ decision
    def arq_score(self, is_retransmission, predict, image_label):
        delay_weight = self.configs.delay_weight
        loss = self.loss_clf(predict, image_label)
        CLF_correct_set = self.correct_set(label=image_label, predicted=predict)
        delay = self.delay(is_retransmission)
        delay = torch.full_like(loss, delay)
        overall_score = loss + delay_weight * delay
        return overall_score, loss, delay, CLF_correct_set
