# import sys
# sys.path.append('D:/XianLi/WSMEC/Task_Oriented_ARQ/CIFAR10BASED')

import torch
import netron
import warnings
import onnx

from models.model import MNISTARQDecisionMaker, MNISTClassifierMLP
from scripts.CLF_Train_and_Test import CLFTrainer, CLFTester
from scripts.ARQ_train_and_test import ARQTrainer, ARQTester, ARQDataGenerator
from configs.configs import create_argparser, set_determenistic_mode
from util.resultplot import result_load, result_plot_dual, result_plot_delay_vs_acc, result_plot_round, result_plot_retrans_ratio

model_dict = {
    'mlp': MNISTClassifierMLP,
}

if __name__ == '__main__':
    configs = create_argparser().parse_args()

    if configs.action == 'train':
        set_determenistic_mode(SEED=configs.random_seed)

    if configs.task == 'CLF':
        CLF_model = model_dict[configs.type_of_model](**vars(configs))

        if configs.action == 'train':
            CLFTrainer(model=CLF_model, configs=configs)
        elif configs.action == 'test':
            CLFTester(model=CLF_model, configs=configs)
        else:
            img = torch.rand((1, 1, 28, 28))
            img = img.to(configs.device)
            CLF_model = CLF_model.to(configs.device)
            torch.onnx.export(model=CLF_model,
                              args=img,
                              f='CLF_{}_model.onnx'.format(configs.type_of_model),
                              input_names=['image'],
                              output_names=['reconstructed image'])
            onnx.save(onnx.shape_inference.infer_shapes(onnx.load('CLF_{}_model.onnx'.format(configs.type_of_model))),
                      'CLF_{}_model.onnx'.format(configs.type_of_model))
            netron.start('CLF_{}_model.onnx'.format(configs.type_of_model))
            warnings.warn('please selection an action for CFL task: train or test.')
    elif configs.task == 'ARQ':
        ARQmodel = MNISTARQDecisionMaker(**vars(configs))
        CLFmodel = model_dict[configs.type_of_model](**vars(configs))
        if configs.action == 'train':
            ARQTrainer(ARQ_model=ARQmodel, configs=configs)
        elif configs.action == 'datagen':
            ARQDataGenerator(ARQ_model=ARQmodel, CLF_model=CLFmodel, configs=configs)
        elif configs.action == 'test':
            ARQTester(ARQ_model=ARQmodel, CLF_model=CLFmodel, configs=configs)
        elif configs.action == 'plot':
            result_path = configs.path + 'results/simulation_result/'
            fig_save_path = configs.path + 'results/simulation_result/figures/'
            data_plot_acc_delay_vs_snr = result_load(path=result_path,
                                                     keyword1='bits4',
                                                     keyword2='weight8',
                                                     sort_key='snr')
            
            result_plot_round(save_path=fig_save_path,save_name='loss_of_round')
            
            result_plot_retrans_ratio(save_name='retrans_ratio_vs_snr', 
                                      save_path=fig_save_path, 
                                      data_plot=data_plot_acc_delay_vs_snr)
            
            result_plot_dual(save_name='acc_delay_vs_snr',
                             save_path=fig_save_path,
                             data_plot=data_plot_acc_delay_vs_snr,
                             key_names1=['arq_acc', 'strans_acc', 'aretrans_acc', 'crc_acc'],
                             key_names2=['arq_delay', 'strans_delay', 'aretrans_delay', 'crc_delay'],
                             line_styles=['-b^', '-gx', '-ko', '-r*'],
                             legend_names=['TARQ', 'STrans', 'ARetrans', 'HARQ'],
                             x_ticks=[-6, -3, 0, 3, 6, 9],
                             y_ticks1=[0.95, 0.85, 0.75, 0.65, 0.55],
                             y_ticks2=[0.02, 0.0175, 0.015, 0.0125, 0.01],
                             y_ticklabels1=[95, 85, 75, 65, 55],
                             y_ticklabels2=[20.0, 17.5, 15.0, 12.5, 10.0],
                             )
            data_plot_acc_vs_delay = result_load(path=result_path,
                                                 keyword1='snr3',
                                                 keyword2='bits4',
                                                 sort_key='weight')

            result_plot_delay_vs_acc(save_name='acc_vs_delay_TARQ',
                                     save_path=fig_save_path,
                                     data_plot=data_plot_acc_vs_delay,
                                     line_styles=['-b^', ],
                                     x_ticks=[0.02, 0.0175, 0.015, 0.0125, 0.01],
                                     x_title='Delay margin (ms)',
                                     y_title='Accuracy (\%)')
        else:
            # img = torch.rand((1, 3, 32, 32))
            print(configs.action)
            snr = torch.rand((1, 2))
            torch.onnx.export(model=ARQmodel, args=snr, f='ARQmodel.onnx', input_names=['image'],
                              output_names=['reconstructed image'])
            onnx.save(onnx.shape_inference.infer_shapes(onnx.load('ARQmodel.onnx')), 'ARQmodel.onnx')
            netron.start('ARQmodel.onnx')
            warnings.warn('please selection an action for ARQ task: train or test.')
    else:
        raise ValueError('please select a task, i.e., IR or ARQ')
